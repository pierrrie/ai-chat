<?php

/**
 * Скопируйте в DOCUMENT_ROOT/config/aichat.config.php и настройте под сайт.
 */
return [
    'shop' => [
        'name' => 'Draxter',
        'brand' => 'Draxter',
        'site_url' => 'https://draxter.ru',
        'specialization' => 'Draxter специализируется на измельчителях древесины, щепорезах и промышленных утилизаторах',
    ],
    'catalog' => [
        'profile' => 'auto', // auto — по товарам в YML; garden — только если в фиде нет мотоснегокатов
        'source' => 'yml_url',
        'url' => 'https://draxter.ru/bitrix/catalog_export/DraxterFidFile_UPDATED.xml',
        'refresh_minutes' => 60,
    ],
    'chat' => [
        'welcome' => 'Здравствуйте! Помогу подобрать измельчитель или щепорез, сравнить модели по мощности и ответить по ценам. Чем могу помочь?',
        'log_enabled' => true,
    ],
    'voice' => [
        'enabled' => true,
        'reply_enabled' => true,
    ],
    'prompts' => [
        'role_line' => 'Ты — AI-консультант «{shop_name}» ({brand}). Помогаешь выбрать измельчитель, щепорез или утилизатор древесины.',
        'rules_common' => 'Правила: только товары из каталога ниже, ссылки в формате [Название](url), русский язык.',
        'catalog_synonyms_line' => 'щепорез, измельчитель, утилизатор, веткорез, древесина',
        'domain_rules' => [
            'В ассортименте нет снегокатов, снегоходов, мотоциклов и мотовездеходов.',
            'На запросы вне каталога — откажи и предложи измельчители или щепорезы из списка ниже.',
        ],
        'faq_intro' => 'Вопросы о доставке, оплате и сервисе — только по faq_knowledge ниже.',
        'faq_knowledge' => "# keywords: доставка, город\nУкажите сроки и стоимость доставки.\n",
    ],
    'intent' => [
        'topic_words' => ['измельчит', 'щепорез', 'утилизатор', 'мульч', 'древесин'],
    ],
];
