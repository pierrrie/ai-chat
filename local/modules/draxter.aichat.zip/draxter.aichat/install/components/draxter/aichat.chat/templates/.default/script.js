(function () {
  const DEFAULT_WELCOME =
    "Здравствуйте! Помогу подобрать товар, сравнить модели и ответить по ценам и наличию. Чем могу помочь?";
  const SESSION_KEY = "draxter_chat_session_id";
  const CLOSE_MS = 280;

  function uid() {
    return Date.now() + "-" + Math.random().toString(36).slice(2, 8);
  }

  function getSessionId() {
    try {
      const existing = sessionStorage.getItem(SESSION_KEY);
      if (existing) return existing;
      const id = "s_" + Date.now() + "_" + Math.random().toString(36).slice(2, 10);
      sessionStorage.setItem(SESSION_KEY, id);
      return id;
    } catch {
      return "s_" + Date.now() + "_" + Math.random().toString(36).slice(2, 10);
    }
  }

  function saveSessionId(id) {
    try {
      sessionStorage.setItem(SESSION_KEY, id);
    } catch {}
  }

  function getCookie(name) {
    const m = document.cookie.match(new RegExp("(?:^|; )" + name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "=([^;]*)"));
    return m ? decodeURIComponent(m[1]) : "";
  }

  function collectTracking() {
    const params = new URLSearchParams(window.location.search);
    const keys = ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content"];
    const tracking = {
      http_referer: document.referrer || "",
      page_url: window.location.href || "",
      page_title: document.title || "",
    };
    keys.forEach((k) => {
      tracking[k] = params.get(k) || getCookie(k) || "";
    });
    tracking._ym_uid = params.get("_ym_uid") || getCookie("_ym_uid") || "";
    return tracking;
  }

  function avatarSvg() {
    return (
      '<svg width="58%" height="58%" viewBox="0 0 252 254" fill="none" xmlns="http://www.w3.org/2000/svg">' +
      '<path fill-rule="evenodd" clip-rule="evenodd" fill="white" d="M22.809 198.668C-16.2274 140.81 -1.74336 61.8142 55.3098 22.2268C112.363 -17.3606 190.259 -2.67212 229.296 55.1864C268.332 113.045 253.848 192.041 196.795 231.628C139.741 271.216 61.8454 256.527 22.809 198.668ZM125.257 124.33C136.739 141.347 143.627 164.097 148.926 188.816L218.697 189.891C202.977 155.319 177.541 127.017 145.57 103.014C155.639 92.6243 168.356 87.6087 181.604 83.6679C163.234 80.0853 144.864 83.6679 126.494 92.2661C104.944 83.1305 86.9276 81.3392 71.3837 84.2053C89.7538 91.0121 99.9985 96.7443 106.357 101.939C73.3266 124.33 49.6575 153.886 34.2903 189.891L101.941 190.429C106.357 163.738 115.189 141.885 125.611 124.151L125.257 124.33Z"/></svg>'
    );
  }

  function renderMarkdown(text) {
    let html = escapeHtml(text);
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_, label, url) => {
      const href = (url || "").trim();
      if (!/^https?:\/\//i.test(href)) {
        return "[" + label + "](" + url + ")";
      }
      return (
        '<a href="' +
        href.replace(/"/g, "&quot;") +
        '" target="_blank" rel="noreferrer noopener">' +
        label +
        "</a>"
      );
    });
    html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    html = html.replace(/\*([^*]+)\*/g, '<em class="drax-em">$1</em>');
    html = html.replace(/\n/g, "<br>");
    return html;
  }

  function escapeHtml(s) {
    return s
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  const FAB_COLLAPSE_SVG =
    '<svg class="draxter-aichat-fab-icon" width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">' +
    '<path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  const MIC_SVG =
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    '<path d="M12 14a3 3 0 003-3V5a3 3 0 10-6 0v6a3 3 0 003 3z" stroke="currentColor" stroke-width="2"/>' +
    '<path d="M19 11v1a7 7 0 01-14 0v-1M12 18v3M8 21h8" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';

  function initRoot(root) {
    if (root.parentElement !== document.body) {
      document.body.appendChild(root);
    }

    const shopName = root.dataset.shopName || "Консультант";
    const agentName = root.dataset.agentName || shopName;
    const statusText = root.dataset.statusText || "Онлайн • отвечает сразу";
    const showOnline = root.dataset.showOnline !== "0";
    const welcomeText = root.dataset.welcome || DEFAULT_WELCOME;
    const ajaxUrl = root.dataset.ajaxUrl || "/local/ajax/draxter_aichat.php";
    const embedded = root.dataset.embedded === "1";
    const avatarUrl = (root.dataset.avatarUrl || "").trim();
    const voiceEnabled = root.dataset.voiceEnabled === "1";
    const voiceReply = root.dataset.voiceReply === "1";
    const voiceMaxSeconds = Math.max(5, parseInt(root.dataset.voiceMaxSeconds || "60", 10) || 60);
    const ymEnabled = root.dataset.ymEnabled === "1";
    const ymCounter = root.dataset.ymCounter || "";
    const ymGoal = root.dataset.ymGoal || "aibot";
    const LEAD_MARKER = "<!--draxter-aichat-lead:1-->";

    function fireMetrikaLeadGoal() {
      if (!ymEnabled) return;
      const counter = parseInt(ymCounter, 10);
      const goal = (ymGoal || "").trim();
      if (!counter || !goal) return;
      try {
        if (typeof ym === "function") {
          ym(counter, "reachGoal", goal);
        }
      } catch (_) {}
    }

    function processLeadCreatedSignal(headerLead, text) {
      let leadCreated = headerLead;
      let out = text || "";
      if (out.includes(LEAD_MARKER)) {
        leadCreated = true;
        out = out.replace(LEAD_MARKER, "").trim();
      }
      if (leadCreated) {
        fireMetrikaLeadGoal();
      }
      return out;
    }

    function avatarHtml(extraClass) {
      const cls = "draxter-aichat-avatar" + (extraClass ? " " + extraClass : "");
      if (avatarUrl) {
        return '<img class="' + cls + '" src="' + escapeHtml(avatarUrl) + '" alt="" loading="lazy">';
      }
      return '<div class="' + cls + '">' + avatarSvg() + "</div>";
    }

    function fabClosedHtml() {
      return (
        avatarHtml("draxter-aichat-fab-avatar") +
        '<span class="draxter-aichat-fab-label"><strong>Чат</strong>' +
        '<span class="draxter-aichat-fab-sublabel">Спросить о товаре</span></span>'
      );
    }

    let panelOpen = embedded;
    let panelMounted = embedded;
    let closing = false;
    let loading = false;
    let recording = false;
    let messages = [{ id: "welcome", role: "assistant", content: welcomeText }];
    let error = null;

    let fab = null;
    let panel = null;
    let listEl = null;
    let inputEl = null;
    let sendBtn = null;
    let micBtn = null;
    let mediaRecorder = null;
    let recordChunks = [];
    let recordMime = "audio/webm";
    let voicePhase = "idle";
    let voiceStatusEl = null;
    let recordStartedAt = 0;

    function setVoiceStatus(text) {
      if (!voiceStatusEl) return;
      if (text) {
        voiceStatusEl.hidden = false;
        voiceStatusEl.textContent = text;
      } else {
        voiceStatusEl.hidden = true;
        voiceStatusEl.textContent = "";
      }
    }

    function pickRecordMime() {
      const types = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg"];
      for (let i = 0; i < types.length; i++) {
        if (MediaRecorder.isTypeSupported(types[i])) return types[i];
      }
      return "";
    }

    function setFabState(isOpen) {
      if (!fab) return;
      if (isOpen) {
        fab.classList.add("draxter-aichat-fab--open");
        fab.innerHTML = FAB_COLLAPSE_SVG;
        fab.setAttribute("aria-label", "Свернуть чат");
        fab.setAttribute("aria-expanded", "true");
      } else {
        fab.classList.remove("draxter-aichat-fab--open");
        fab.innerHTML = fabClosedHtml();
        fab.setAttribute("aria-label", "Открыть чат с консультантом");
        fab.setAttribute("aria-expanded", "false");
      }
    }

    function updateSendButton() {
      if (!sendBtn || !inputEl) return;
      sendBtn.disabled = loading || recording || !(inputEl.value || "").trim();
      if (micBtn) micBtn.disabled = loading;
    }

    function scrollBottom() {
      if (listEl) listEl.scrollTop = listEl.scrollHeight;
    }

    function renderMessages() {
      if (!listEl) return;
      listEl.innerHTML = "";
      const lastMsg = messages[messages.length - 1];
      const showTyping =
        loading &&
        (voicePhase === "transcribing" ||
          !lastMsg ||
          lastMsg.role === "user" ||
          (lastMsg.role === "assistant" && !lastMsg.content && !lastMsg.audioUrl));

      messages.forEach((m) => {
        if (m.role === "assistant") {
          if (!m.content && !m.audioUrl && showTyping) return;
          const row = document.createElement("div");
          row.className = "draxter-aichat-msg";
          let inner = avatarHtml() + '<div class="draxter-aichat-bubble draxter-aichat-bubble--bot">';
          if (m.content) inner += renderMarkdown(m.content);
          if (m.audioUrl) {
            inner +=
              '<div class="draxter-aichat-audio-wrap"><audio controls preload="none" src="' +
              escapeHtml(m.audioUrl) +
              '"></audio></div>';
          }
          inner += "</div>";
          row.innerHTML = inner;
          listEl.appendChild(row);
        } else {
          const row = document.createElement("div");
          row.className = "draxter-aichat-msg draxter-aichat-msg--user";
          row.innerHTML =
            '<div class="draxter-aichat-bubble draxter-aichat-bubble--user">' +
            escapeHtml(m.content) +
            "</div>";
          listEl.appendChild(row);
        }
      });

      if (showTyping) {
        const t = document.createElement("div");
        t.className = "draxter-aichat-msg";
        t.innerHTML =
          avatarHtml() +
          '<div class="draxter-aichat-bubble draxter-aichat-bubble--bot draxter-aichat-typing"><span></span><span></span><span></span></div>';
        listEl.appendChild(t);
      }

      if (error) {
        const e = document.createElement("p");
        e.className = "draxter-aichat-error";
        e.textContent = error;
        listEl.appendChild(e);
      }

      scrollBottom();
    }

    function speakWithBrowserTts(plain) {
      if (!window.speechSynthesis || !plain) return false;
      const u = new SpeechSynthesisUtterance(plain);
      u.lang = "ru-RU";
      u.rate = 1;
      speechSynthesis.cancel();
      speechSynthesis.speak(u);
      return true;
    }

    async function playTtsForMessage(assistantId, text) {
      if (!voiceReply || !text.trim()) return;
      try {
        const sep = ajaxUrl.indexOf("?") >= 0 ? "&" : "?";
        const res = await fetch(ajaxUrl + sep + "action=tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text }),
        });
        const contentType = (res.headers.get("Content-Type") || "").toLowerCase();
        if (contentType.indexOf("application/json") >= 0) {
          const data = await res.json();
          if (data.mode === "browser" && data.text) {
            speakWithBrowserTts(data.text);
            return;
          }
        }
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          const msg =
            data.error ||
            "Озвучка недоступна (HTTP " + res.status + ").";
          const plain = text.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/<[^>]+>/g, "");
          if (speakWithBrowserTts(plain.slice(0, 500))) {
            setVoiceStatus("Озвучка браузера");
            setTimeout(() => setVoiceStatus(""), 4000);
            return;
          }
          setVoiceStatus(msg);
          setTimeout(() => setVoiceStatus(""), 6000);
          return;
        }
        const blob = await res.blob();
        if (!blob.size) {
          throw new Error("Пустой аудиофайл от сервера");
        }
        const url = URL.createObjectURL(blob);
        const idx = messages.findIndex((m) => m.id === assistantId);
        if (idx >= 0) {
          if (messages[idx].audioUrl) URL.revokeObjectURL(messages[idx].audioUrl);
          messages[idx].audioUrl = url;
          renderMessages();
          const audios = listEl.querySelectorAll("audio");
          const last = audios[audios.length - 1];
          if (last) last.play().catch(function () {});
        }
      } catch (e) {
        const plain = text.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/<[^>]+>/g, "");
        if (!speakWithBrowserTts(plain.slice(0, 500))) {
          setVoiceStatus(e.message || "Не удалось озвучить ответ");
          setTimeout(() => setVoiceStatus(""), 6000);
        }
      }
    }

    async function sendText(text, autoFromVoice) {
      const trimmed = (text || "").trim();
      if (!trimmed || loading) return;

      messages.push({ id: uid(), role: "user", content: trimmed });
      if (inputEl) inputEl.value = "";
      loading = true;
      error = null;
      updateSendButton();
      renderMessages();

      const payload = {
        sessionId: getSessionId(),
        tracking: collectTracking(),
        messages: messages
          .filter((m) => m.id !== "welcome")
          .map(({ role, content }) => ({ role, content })),
      };

      const CHAT_TIMEOUT_MS = 240000;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), CHAT_TIMEOUT_MS);

      try {
        const res = await fetch(ajaxUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
          signal: controller.signal,
        });
        clearTimeout(timeoutId);

        const sessionHeader = res.headers.get("X-Chat-Session-Id");
        if (sessionHeader) saveSessionId(sessionHeader);

        const contentType = res.headers.get("content-type") || "";
        if (!res.ok || contentType.includes("application/json")) {
          const data = await res.json().catch(() => ({}));
          if (res.status === 504) {
            throw new Error(
              data.error ||
                "Сервер не успел ответить вовремя. Попробуйте ещё раз или сократите вопрос."
            );
          }
          throw new Error(data.error || "Ошибка " + res.status);
        }
        if (res.ok && contentType.includes("text/plain") && !contentType.includes("json")) {
          const plain = processLeadCreatedSignal(
            res.headers.get("X-Chat-Lead-Created") === "1",
            (await res.text()).trim()
          );
          if (!plain) {
            throw new Error("Пустой ответ сервера.");
          }
          messages.push({ id: uid(), role: "assistant", content: plain });
          renderMessages();
          return;
        }
        if (!res.body) {
          throw new Error("Сервер не вернул поток ответа");
        }

        const assistantId = uid();
        messages.push({ id: assistantId, role: "assistant", content: "" });
        renderMessages();

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let assistantText = "";

        let renderScheduled = false;
        function scheduleRender() {
          if (renderScheduled) return;
          renderScheduled = true;
          requestAnimationFrame(() => {
            renderScheduled = false;
            renderMessages();
          });
        }

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          assistantText += decoder.decode(value, { stream: true });
          const idx = messages.findIndex((m) => m.id === assistantId);
          if (idx >= 0) messages[idx].content = assistantText;
          scheduleRender();
        }
        assistantText += decoder.decode();
        assistantText = assistantText.replace(/^\s+/, "");
        assistantText = processLeadCreatedSignal(
          res.headers.get("X-Chat-Lead-Created") === "1",
          assistantText
        );
        const idxFinal = messages.findIndex((m) => m.id === assistantId);
        if (idxFinal >= 0) messages[idxFinal].content = assistantText;
        if (!assistantText.trim()) {
          throw new Error("Пустой ответ сервера. Обновите страницу и попробуйте снова.");
        }

        if (voiceReply) {
          await playTtsForMessage(assistantId, assistantText);
        }
      } catch (e) {
        if (e.name === "AbortError") {
          error = "Ответ слишком долгий. Попробуйте короче сформулировать запрос или повторите позже.";
        } else {
          error = e.message || "Ошибка отправки";
          if (
            autoFromVoice &&
            /лимит|квот|gemini|429|quota|исчерпан/i.test(error)
          ) {
            error +=
              " Подождите 30–60 сек. или введите текстом. Голос = распознавание + ответ (два запроса к API).";
          }
        }
        const last = messages[messages.length - 1];
        if (last && last.role === "assistant" && !last.content) messages.pop();
        renderMessages();
      } finally {
        clearTimeout(timeoutId);
        loading = false;
        updateSendButton();
        renderMessages();
      }
    }

    async function send() {
      await sendText(inputEl ? inputEl.value : "");
    }

    function transcribeUrl() {
      const sep = ajaxUrl.indexOf("?") >= 0 ? "&" : "?";
      return ajaxUrl + sep + "action=transcribe";
    }

    async function transcribeBlob(blob) {
      const ext = blob.type.indexOf("mp4") >= 0 ? "m4a" : blob.type.indexOf("ogg") >= 0 ? "ogg" : "webm";
      const fd = new FormData();
      fd.append("audio", blob, "voice." + ext);
      const res = await fetch(transcribeUrl(), { method: "POST", body: fd });
      const raw = await res.text();
      let data = {};
      try {
        data = raw ? JSON.parse(raw) : {};
      } catch {
        if (!res.ok) {
          throw new Error("Ошибка распознавания (HTTP " + res.status + ")");
        }
      }
      if (!res.ok) {
        throw new Error(data.error || data.message || "Ошибка распознавания (HTTP " + res.status + ")");
      }
      return (data.text || "").trim();
    }

    function stopRecording() {
      if (!mediaRecorder || mediaRecorder.state === "inactive") return;
      try {
        if (mediaRecorder.state === "recording") {
          mediaRecorder.requestData();
        }
      } catch {}
      mediaRecorder.stop();
    }

    async function startRecording() {
      if (loading || recording) return;
      if (!voiceEnabled) {
        error =
          "Голосовой ввод отключён. Включите «Голосовой ввод» в настройках модуля draxter.aichat (вкладка «Голос»).";
        renderMessages();
        return;
      }
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        error = "Браузер не поддерживает запись с микрофона";
        renderMessages();
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        recordChunks = [];
        recordMime = pickRecordMime() || "audio/webm";
        const recOptions = recordMime ? { mimeType: recordMime } : undefined;
        mediaRecorder = recOptions ? new MediaRecorder(stream, recOptions) : new MediaRecorder(stream);
        const maxMs = voiceMaxSeconds * 1000;
        const stopTimer = setTimeout(() => stopRecording(), maxMs);

        mediaRecorder.ondataavailable = (e) => {
          if (e.data && e.data.size > 0) recordChunks.push(e.data);
        };

        mediaRecorder.onerror = () => {
          voicePhase = "idle";
          recording = false;
          setVoiceStatus("");
          error = "Ошибка записи с микрофона";
          stream.getTracks().forEach((t) => t.stop());
          renderMessages();
        };

        mediaRecorder.onstop = async () => {
          clearTimeout(stopTimer);
          stream.getTracks().forEach((t) => t.stop());
          recording = false;
          if (micBtn) {
            micBtn.classList.remove("draxter-aichat-mic--active");
            micBtn.setAttribute("aria-label", "Голосовое сообщение");
          }
          updateSendButton();

          const blobType =
            recordMime || (mediaRecorder && mediaRecorder.mimeType) || "audio/webm";
          const blob = new Blob(recordChunks, { type: blobType });
          recordChunks = [];
          mediaRecorder = null;

          const durationMs = Date.now() - recordStartedAt;
          if (!blob.size || blob.size < 400) {
            voicePhase = "idle";
            setVoiceStatus("");
            error =
              durationMs < 600
                ? "Запись слишком короткая. Удерживайте микрофон 1–2 секунды и отпустите."
                : "Не удалось записать звук. Проверьте микрофон и разрешение браузера.";
            renderMessages();
            return;
          }

          voicePhase = "transcribing";
          loading = true;
          error = null;
          setVoiceStatus("Распознаём речь…");
          renderMessages();

          try {
            const text = await transcribeBlob(blob);
            voicePhase = "idle";
            setVoiceStatus("");
            loading = false;
            if (!text) {
              error = "Не удалось распознать речь. Говорите чётче или добавьте OPENAI_API_KEY (Whisper).";
              renderMessages();
              return;
            }
            if (inputEl) inputEl.value = text;
            await sendText(text, true);
          } catch (e) {
            voicePhase = "idle";
            setVoiceStatus("");
            loading = false;
            error = e.message || "Ошибка голоса";
            renderMessages();
          }
        };

        mediaRecorder.start(250);
        recording = true;
        voicePhase = "recording";
        recordStartedAt = Date.now();
        setVoiceStatus("Запись… Нажмите микрофон ещё раз, чтобы отправить");
        if (micBtn) {
          micBtn.classList.add("draxter-aichat-mic--active");
          micBtn.setAttribute("aria-label", "Остановить запись и отправить");
        }
        updateSendButton();
      } catch (e) {
        voicePhase = "idle";
        setVoiceStatus("");
        error = "Нет доступа к микрофону. Разрешите доступ в настройках браузера.";
        renderMessages();
      }
    }

    function buildPanel() {
      panel = document.createElement("div");
      panel.className = "draxter-aichat-panel";
      panel.setAttribute("role", "dialog");
      const micHtml = voiceEnabled
        ? '<button type="button" class="draxter-aichat-mic" aria-label="Голосовое сообщение" title="Голосовое сообщение">' +
          MIC_SVG +
          "</button>"
        : "";
      const voiceStatusHtml =
        voiceEnabled || voiceReply
          ? '<p class="draxter-aichat-voice-status" hidden></p>'
          : "";
      const statusHtml = showOnline
        ? '<p class="draxter-aichat-status">' +
          '<span class="draxter-aichat-status-dot" aria-hidden="true"></span>' +
          '<span class="draxter-aichat-status-text"></span></p>'
        : "";
      panel.innerHTML =
        '<header class="draxter-aichat-header">' +
        '<div class="draxter-aichat-header-main">' +
        avatarHtml("draxter-aichat-header-avatar") +
        '<div class="draxter-aichat-header-text">' +
        '<p class="draxter-aichat-title"></p>' +
        statusHtml +
        "</div></div>" +
        (embedded ? "" : '<button type="button" class="draxter-aichat-close" aria-label="Закрыть">✕</button>') +
        "</header>" +
        '<div class="draxter-aichat-messages"></div>' +
        '<footer class="draxter-aichat-footer">' +
        voiceStatusHtml +
        '<div class="draxter-aichat-footer-row">' +
        micHtml +
        '<textarea class="draxter-aichat-input" rows="1" placeholder="Сообщение…"></textarea>' +
        '<button type="button" class="draxter-aichat-send" aria-label="Отправить">➤</button>' +
        "</div></footer>";

      panel.querySelector(".draxter-aichat-title").textContent = agentName;
      const statusEl = panel.querySelector(".draxter-aichat-status-text");
      if (statusEl) statusEl.textContent = statusText;
      listEl = panel.querySelector(".draxter-aichat-messages");
      inputEl = panel.querySelector(".draxter-aichat-input");
      sendBtn = panel.querySelector(".draxter-aichat-send");
      micBtn = panel.querySelector(".draxter-aichat-mic");
      voiceStatusEl = panel.querySelector(".draxter-aichat-voice-status");

      if (!embedded) {
        panel.querySelector(".draxter-aichat-close").addEventListener("click", closePanel);
      }

      sendBtn.addEventListener("click", send);
      inputEl.addEventListener("input", updateSendButton);
      inputEl.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          send();
        }
      });

      if (micBtn) {
        micBtn.addEventListener("click", () => {
          if (recording) stopRecording();
          else startRecording();
        });
      }

      updateSendButton();
      renderMessages();
      return panel;
    }

    function openPanel() {
      if (!panelMounted) {
        panelMounted = true;
        root.appendChild(buildPanel());
      }
      closing = false;
      panel.classList.remove("draxter-aichat-panel--closing");
      requestAnimationFrame(() => {
        panelOpen = true;
        root.classList.add("draxter-aichat-root--panel-open");
        setFabState(true);
        setTimeout(() => inputEl && inputEl.focus(), 200);
      });
    }

    function closePanel() {
      if (embedded) return;
      if (recording) stopRecording();
      closing = true;
      panelOpen = false;
      root.classList.remove("draxter-aichat-root--panel-open");
      panel.classList.add("draxter-aichat-panel--closing");
      setFabState(false);
      setTimeout(() => {
        if (panel && panel.parentNode) panel.parentNode.removeChild(panel);
        panelMounted = false;
        panel = null;
        closing = false;
      }, CLOSE_MS);
    }

    if (embedded) {
      root.appendChild(buildPanel());
      panelOpen = true;
      root.classList.add("draxter-aichat-root--panel-open");
      return;
    }

    fab = document.createElement("button");
    fab.type = "button";
    fab.className = "draxter-aichat-fab";
    fab.setAttribute("aria-expanded", "false");
    fab.innerHTML = fabClosedHtml();

    fab.addEventListener("click", () => {
      if (panelOpen && panelMounted && !closing) closePanel();
      else openPanel();
    });

    root.appendChild(fab);
  }

  document.querySelectorAll(".draxter-aichat-root").forEach(initRoot);
})();
