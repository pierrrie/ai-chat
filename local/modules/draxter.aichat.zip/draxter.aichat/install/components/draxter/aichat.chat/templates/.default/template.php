<?php

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

/** @var array $arResult */
/** @var CBitrixComponentTemplate $this */
$shopName = htmlspecialcharsbx($arResult['SHOP_NAME']);
$agentName = htmlspecialcharsbx($arResult['AGENT_NAME'] ?? $shopName);
$embedded = $arResult['EMBEDDED'] === 'Y';
$ajaxUrl = htmlspecialcharsbx($arResult['AJAX_URL']);
$avatarUrl = htmlspecialcharsbx($arResult['AVATAR_URL'] ?? '');
$accent = htmlspecialcharsbx($arResult['ACCENT_COLOR'] ?? '#2563eb');
$fabRight = htmlspecialcharsbx($arResult['FAB_RIGHT'] ?? '24');
$fabBottom = htmlspecialcharsbx($arResult['FAB_BOTTOM'] ?? '24');
$assetVer = '2.1.1';
$cssUrl = $templateFolder . '/style.css';
$jsUrl = $templateFolder . '/script.js';
?>
<link rel="stylesheet" href="<?= htmlspecialcharsbx($cssUrl) ?>?v=<?= htmlspecialcharsbx($assetVer) ?>">
<div
    class="draxter-aichat-root"
    style="--drax-accent: <?= $accent ?>; --drax-fab-right: <?= $fabRight ?>px; --drax-fab-bottom: <?= $fabBottom ?>px;"
    data-shop-name="<?= $shopName ?>"
    data-agent-name="<?= $agentName ?>"
    data-status-text="<?= htmlspecialcharsbx($arResult['STATUS_TEXT'] ?? 'Онлайн • отвечает сразу') ?>"
    data-show-online="<?= htmlspecialcharsbx($arResult['SHOW_ONLINE'] ?? '1') ?>"
    data-welcome="<?= htmlspecialcharsbx($arResult['WELCOME']) ?>"
    data-ajax-url="<?= $ajaxUrl ?>"
    data-embedded="<?= $embedded ? '1' : '0' ?>"
    data-avatar-url="<?= $avatarUrl ?>"
    data-voice-enabled="<?= htmlspecialcharsbx($arResult['VOICE_ENABLED'] ?? '0') ?>"
    data-voice-reply="<?= htmlspecialcharsbx($arResult['VOICE_REPLY'] ?? '0') ?>"
    data-voice-max-seconds="<?= htmlspecialcharsbx($arResult['VOICE_MAX_SECONDS'] ?? '60') ?>"
    data-ym-enabled="<?= htmlspecialcharsbx($arResult['YM_ENABLED'] ?? '0') ?>"
    data-ym-counter="<?= htmlspecialcharsbx($arResult['YM_COUNTER'] ?? '') ?>"
    data-ym-goal="<?= htmlspecialcharsbx($arResult['YM_GOAL'] ?? 'aibot') ?>"
></div>
<script src="<?= htmlspecialcharsbx($jsUrl) ?>?v=<?= htmlspecialcharsbx($assetVer) ?>" defer></script>
