<?php

namespace Draxter\Aichat;

class ResponseEnrich
{
    /**
     * Дописывает в поток блок ссылок, если модель их не вставила.
     *
     * @param array<int, array{role: string, content: string}> $messages
     */
    public static function buildStreamSuffix(string $text, array $messages, string $siteUrl): string
    {
        $text = trim($text);
        if ($text === '') {
            return '';
        }

        $products = self::collectProducts($text, $messages);
        if ($products === []) {
            return '';
        }

        $enriched = self::injectProductLinks($text, $products, $siteUrl);
        if ($enriched !== $text && self::hasMarkdownLinks($enriched)) {
            return mb_substr($enriched, mb_strlen($text));
        }

        if (self::hasMarkdownLinks($text)) {
            $missing = [];
            foreach ($products as $p) {
                $url = Catalog::productLink($p, $siteUrl);
                if (!str_contains($text, $url)) {
                    $missing[] = $p;
                }
            }
            if ($missing === []) {
                return '';
            }
            $products = $missing;
        }

        return "\n\n" . self::formatLinkBlock($products, $siteUrl);
    }

    /**
     * @param Product[] $products
     */
    public static function enrich(string $text, array $products, string $siteUrl): string
    {
        if ($text === '' || !$products) {
            return $text;
        }
        $withLinks = self::injectProductLinks($text, $products, $siteUrl);
        if (self::hasMarkdownLinks($withLinks)) {
            return $withLinks;
        }

        return $withLinks . "\n\n" . self::formatLinkBlock($products, $siteUrl);
    }

    public static function userWantsProductLinks(string $text): bool
    {
        return (bool)preg_match(
            '/ссылк|url\b|где\s+купить|на\s+сайт|страниц.{0,10}товар|прям.{0,6}ссыл/ui',
            $text
        );
    }

    /**
     * @param array<int, array{role: string, content: string}> $messages
     * @return Product[]
     */
    public static function collectProducts(string $assistantText, array $messages): array
    {
        $byId = [];
        foreach (ContextSearch::findProductsForChat($messages, 12) as $p) {
            $byId[$p->id] = $p;
        }
        foreach (self::productsMentionedInText($assistantText) as $p) {
            $byId[$p->id] = $p;
        }

        $lastUser = '';
        for ($i = count($messages) - 1; $i >= 0; $i--) {
            if (($messages[$i]['role'] ?? '') === 'user') {
                $lastUser = $messages[$i]['content'] ?? '';
                break;
            }
        }
        if ($lastUser !== '' && self::userWantsProductLinks($lastUser)) {
            $lastAssistant = '';
            for ($i = count($messages) - 1; $i >= 0; $i--) {
                if (($messages[$i]['role'] ?? '') === 'assistant') {
                    $lastAssistant = $messages[$i]['content'] ?? '';
                    break;
                }
            }
            if ($lastAssistant !== '') {
                foreach (self::productsMentionedInText($lastAssistant) as $p) {
                    $byId[$p->id] = $p;
                }
            }
        }

        return array_values($byId);
    }

    /**
     * @return Product[]
     */
    public static function productsMentionedInText(string $text): array
    {
        if (trim($text) === '') {
            return [];
        }

        $found = [];
        $lower = mb_strtolower($text);
        foreach (Catalog::getAllProducts() as $p) {
            $nameLower = mb_strtolower($p->name);
            if (mb_strpos($lower, $nameLower) !== false) {
                $found[$p->id] = $p;
                continue;
            }
            $short = mb_substr($p->name, 0, 28);
            if (mb_strlen($short) >= 12 && mb_stripos($text, $short) !== false) {
                $found[$p->id] = $p;
                continue;
            }
            if (preg_match('/[сc]\s*[-–]?\s*380/ui', $p->name) && preg_match('/[сc]\s*[-–]?\s*380/ui', $text)) {
                $wantsSport = (bool)preg_match('/sport|спорт/ui', $text);
                $wantsExtreme = (bool)preg_match('/extreme|экстрим/ui', $text);
                $wantsLite = (bool)preg_match('/\blite\b|лайт/ui', $text);
                $isSport = (bool)preg_match('/sport|спорт/ui', $p->name);
                $isExtreme = (bool)preg_match('/extreme|экстрим/ui', $p->name);
                $isLite = (bool)preg_match('/\blite\b|лайт/ui', $p->name);
                if (($wantsSport && $isSport) || ($wantsExtreme && $isExtreme) || ($wantsLite && $isLite)
                    || (!$wantsSport && !$wantsExtreme && !$wantsLite)) {
                    $found[$p->id] = $p;
                }
            }
        }

        return array_values($found);
    }

    private static function hasMarkdownLinks(string $text): bool
    {
        return (bool)preg_match('/\[[^\]]+\]\(https?:\/\/[^\s)]+\)/ui', $text);
    }

    /**
     * @param Product[] $products
     */
    private static function injectProductLinks(string $text, array $products, string $siteUrl): string
    {
        $result = $text;
        usort($products, static fn(Product $a, Product $b) => mb_strlen($b->name) <=> mb_strlen($a->name));

        foreach ($products as $p) {
            $url = Catalog::productLink($p, $siteUrl);
            if ($url === '' || str_contains($result, $url)) {
                continue;
            }
            $variants = [$p->name, str_replace(['«', '»'], '"', $p->name)];
            if (preg_match('/«[^»]+»/u', $p->name, $m)) {
                $variants[] = trim($m[0]);
            }
            foreach ($variants as $variant) {
                if (mb_strlen($variant) < 10) {
                    continue;
                }
                $esc = preg_quote($variant, '/');
                $re = '/(?<!\[)' . $esc . '(?!\]\()/u';
                if (preg_match($re, $result)) {
                    $result = preg_replace($re, '[' . $variant . '](' . $url . ')', $result, 1);
                    break;
                }
            }
        }

        return $result;
    }

    /**
     * @param Product[] $products
     */
    private static function formatLinkBlock(array $products, string $siteUrl, int $max = 6): string
    {
        $lines = ['**Ссылки на товары:**'];
        foreach (array_slice($products, 0, $max) as $p) {
            $url = Catalog::productLink($p, $siteUrl);
            if ($url === '') {
                continue;
            }
            $stock = $p->inStock ? 'в наличии' : 'нет в наличии';
            $lines[] = '**[' . $p->name . '](' . $url . ')** — ' . Catalog::formatPrice($p) . ' · ' . $stock;
        }

        return count($lines) > 1 ? implode("\n", $lines) : '';
    }
}
