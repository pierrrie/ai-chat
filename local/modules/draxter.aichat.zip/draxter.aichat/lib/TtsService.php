<?php

namespace Draxter\Aichat;

class TtsService
{
    /**
     * @return array{mode: string, text?: string, audio?: string, contentType?: string}
     */
    public static function synthesize(string $text): array
    {
        $provider = Settings::voiceTtsProvider();
        if ($provider === 'browser') {
            return ['mode' => 'browser', 'text' => self::preparePlainText($text)];
        }
        if ($provider === 'yandex') {
            $audio = self::synthesizeYandex($text);

            return ['mode' => 'audio', 'audio' => $audio, 'contentType' => 'audio/mpeg'];
        }

        $audio = VoiceService::synthesizeOpenAi($text);

        return ['mode' => 'audio', 'audio' => $audio, 'contentType' => 'audio/mpeg'];
    }

    public static function isConfigured(): bool
    {
        $provider = Settings::voiceTtsProvider();
        if ($provider === 'browser') {
            return true;
        }
        if ($provider === 'yandex') {
            return trim(Settings::get('YANDEX_TTS_API_KEY', '')) !== ''
                && trim(Settings::get('YANDEX_TTS_FOLDER_ID', '')) !== '';
        }

        return trim(Config::get('OPENAI_API_KEY', '')) !== '';
    }

    public static function preparePlainText(string $text): string
    {
        $max = Settings::voiceTtsMaxChars();
        $plain = trim(preg_replace('/\[([^\]]+)\]\([^)]+\)/', '$1', $text) ?? $text);
        $plain = strip_tags($plain);
        if (mb_strlen($plain) > $max) {
            $plain = mb_substr($plain, 0, $max) . '…';
        }

        return $plain;
    }

    private static function synthesizeYandex(string $text): string
    {
        $apiKey = trim(Settings::get('YANDEX_TTS_API_KEY', ''));
        $folderId = trim(Settings::get('YANDEX_TTS_FOLDER_ID', ''));
        if ($apiKey === '' || $folderId === '') {
            throw new \RuntimeException('Для Yandex TTS укажите API-ключ и Folder ID в настройках модуля');
        }

        $plain = self::preparePlainText($text);
        if ($plain === '') {
            throw new \RuntimeException('Пустой текст для озвучки');
        }

        $voice = Settings::yandexTtsVoice();
        $query = http_build_query([
            'text' => $plain,
            'lang' => 'ru-RU',
            'voice' => $voice,
            'folderId' => $folderId,
            'format' => 'mp3',
        ]);

        $url = 'https://tts.api.cloud.yandex.net/speech/v1/tts:synthesize?' . $query;
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Api-Key ' . $apiKey,
            ],
            CURLOPT_TIMEOUT => 120,
        ]);
        CurlHelper::applySslOptions($ch);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        CurlHelper::close($ch);

        if ($code !== 200 || !is_string($body) || $body === '') {
            ApiErrorLog::write('yandex', 'tts', $code, 'Yandex TTS HTTP ' . $code);
            throw new \RuntimeException('Ошибка TTS Yandex: HTTP ' . $code);
        }

        return $body;
    }
}
