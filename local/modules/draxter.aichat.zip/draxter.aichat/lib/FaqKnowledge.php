<?php

namespace Draxter\Aichat;

/**
 * Справочник ответов вне каталога (доставка, оплата, дилеры, техника).
 * Формат в админке (каждый блок):
 *   # keywords: доставка, город, срок
 *   # title: Доставка (необязательно)
 *   Текст ответа для нейросети…
 */
class FaqKnowledge
{
    private const MAX_SECTIONS = 16;
    private const MAX_CHARS = 12000;

    /**
     * @param array<int, array{role: string, content: string}> $messages
     */
    public static function buildPromptSection(string $lastUser, array $messages): string
    {
        $intro = trim(Settings::getString('prompts.faq_intro', ''));
        $raw = trim(Settings::faqKnowledgeRaw());
        if ($intro === '' && $raw === '') {
            return '';
        }

        $sections = self::parseSections($raw);
        $haystack = self::userTextHaystack($lastUser, $messages);
        $selected = self::selectSections($sections, $haystack);

        $parts = [];
        if ($intro !== '') {
            $parts[] = $intro;
        }
        $parts[] = '--- Справочник компании (вопросы не из каталога товаров) ---';
        if ($selected === []) {
            $parts[] = 'В справочнике нет готового ответа — кратко предложи связаться с менеджером {brand} (телефон в чате).';
        } else {
            foreach ($selected as $section) {
                if ($section['title'] !== '') {
                    $parts[] = '### ' . $section['title'];
                }
                $parts[] = $section['body'];
            }
        }
        $parts[] = '--- Конец справочника ---';

        $block = Settings::format(implode("\n", $parts), ['brand' => Config::brand()]);

        return mb_strlen($block) > self::MAX_CHARS
            ? mb_substr($block, 0, self::MAX_CHARS) . "\n…"
            : $block;
    }

    /**
     * @return array{question: string, matched: array<int, array{title: string, keywords: string[]}>, promptSection: string}
     */
    public static function adminPreview(string $question): array
    {
        $messages = [['role' => 'user', 'content' => $question]];
        $raw = trim(Settings::faqKnowledgeRaw());
        $sections = self::parseSections($raw);
        $haystack = self::userTextHaystack($question, $messages);
        $selected = self::selectSections($sections, $haystack);

        $matched = [];
        foreach ($selected as $section) {
            $matched[] = [
                'title' => $section['title'],
                'keywords' => $section['keywords'],
            ];
        }

        return [
            'question' => $question,
            'matched' => $matched,
            'promptSection' => self::buildPromptSection($question, $messages),
        ];
    }

    /**
     * @return array<int, array{keywords: string[], title: string, body: string}>
     */
    public static function parseSections(string $raw): array
    {
        $raw = trim(str_replace(["\r\n", "\r"], "\n", $raw));
        if ($raw === '') {
            return [];
        }

        if (!preg_match('/^#\s*(keywords|ключевые)/umi', $raw)) {
            return [[
                'keywords' => [],
                'title' => '',
                'body' => $raw,
            ]];
        }

        $lines = explode("\n", $raw);
        $sections = [];
        $current = null;

        $flush = static function () use (&$sections, &$current): void {
            if ($current === null) {
                return;
            }
            $body = trim($current['body']);
            if ($body !== '' || $current['title'] !== '' || $current['keywords'] !== []) {
                $sections[] = [
                    'keywords' => $current['keywords'],
                    'title' => $current['title'],
                    'body' => $body,
                ];
            }
            $current = null;
        };

        foreach ($lines as $line) {
            $trimmed = trim($line);
            if ($trimmed === '' || $trimmed === '---') {
                continue;
            }

            if (preg_match('/^#\s*(keywords|ключевые)\s*:\s*(.+)$/ui', $trimmed, $m)) {
                $flush();
                $current = [
                    'keywords' => self::splitKeywords($m[2]),
                    'title' => '',
                    'body' => '',
                ];
                continue;
            }

            if (preg_match('/^#\s*(.+)$/u', $trimmed, $m) && $current !== null
                && !preg_match('/^title\s*:/ui', $m[1])
            ) {
                if (preg_match('/^title\s*:\s*(.+)$/ui', $m[1], $tm)) {
                    $current['title'] = trim($tm[1]);
                } elseif (str_contains($m[1], ',')) {
                    $current['keywords'] = array_merge($current['keywords'], self::splitKeywords($m[1]));
                } else {
                    $current['keywords'][] = mb_strtolower(trim($m[1]));
                }
                continue;
            }

            if (preg_match('/^##\s+(.+)$/u', $trimmed, $m)) {
                $flush();
                $current = ['keywords' => [], 'title' => trim($m[1]), 'body' => ''];
                continue;
            }

            if ($current === null) {
                $current = ['keywords' => [], 'title' => '', 'body' => ''];
            }
            $current['body'] .= ($current['body'] === '' ? '' : "\n") . $line;
        }

        $flush();

        return array_slice($sections, 0, self::MAX_SECTIONS);
    }

    /**
     * @param array<int, array{keywords: string[], title: string, body: string}> $sections
     * @return array<int, array{keywords: string[], title: string, body: string}>
     */
    private static function selectSections(array $sections, string $haystack): array
    {
        if ($sections === []) {
            return [];
        }

        $matched = [];
        foreach ($sections as $section) {
            if ($section['keywords'] === []) {
                $matched[] = $section;
                continue;
            }
            foreach ($section['keywords'] as $kw) {
                if ($kw !== '' && mb_strpos($haystack, $kw) !== false) {
                    $matched[] = $section;
                    break;
                }
            }
        }

        if ($matched !== []) {
            return $matched;
        }

        return $sections;
    }

    /**
     * @param array<int, array{role: string, content: string}> $messages
     */
    private static function userTextHaystack(string $lastUser, array $messages): string
    {
        $chunks = [mb_strtolower($lastUser)];
        $userCount = 0;
        for ($i = count($messages) - 1; $i >= 0 && $userCount < 4; $i--) {
            if (($messages[$i]['role'] ?? '') !== 'user') {
                continue;
            }
            $chunks[] = mb_strtolower(trim((string)($messages[$i]['content'] ?? '')));
            $userCount++;
        }

        return implode(' ', $chunks);
    }

    /**
     * @return string[]
     */
    private static function splitKeywords(string $line): array
    {
        $parts = preg_split('/[,;|]+/u', $line) ?: [];

        return array_values(array_filter(array_map(
            static fn($w) => mb_strtolower(trim($w)),
            $parts
        ), static fn($w) => $w !== '' && mb_strlen($w) >= 2));
    }
}
