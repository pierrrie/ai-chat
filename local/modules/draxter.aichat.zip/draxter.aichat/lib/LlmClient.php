<?php

namespace Draxter\Aichat;

use Bitrix\Main\Web\HttpClient;
use Bitrix\Main\Web\Json;

class LlmClient
{
    /** @return array{url: string, apiKey: string, model: string, provider: string} */
    public static function create(): array
    {
        $provider = Config::aiProvider();

        if ($provider === 'gemini') {
            $apiKey = Config::get('GEMINI_API_KEY');
            if ($apiKey === '') {
                throw new \RuntimeException('NO_API_KEY');
            }
            return [
                'provider' => 'gemini',
                'apiKey' => $apiKey,
                'model' => Config::get('GEMINI_MODEL', 'gemini-2.0-flash'),
                'url' => 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
            ];
        }

        if ($provider === 'deepseek') {
            $apiKey = Config::get('DEEPSEEK_API_KEY');
            if ($apiKey === '') {
                throw new \RuntimeException('NO_API_KEY');
            }
            return [
                'provider' => 'deepseek',
                'apiKey' => $apiKey,
                'model' => Config::get('DEEPSEEK_MODEL', 'deepseek-chat'),
                'url' => 'https://api.deepseek.com/chat/completions',
            ];
        }

        $apiKey = Config::get('OPENAI_API_KEY');
        if ($apiKey === '') {
            throw new \RuntimeException('NO_API_KEY');
        }
        return [
            'provider' => 'openai',
            'apiKey' => $apiKey,
            'model' => Config::get('OPENAI_MODEL', 'gpt-4o-mini'),
            'url' => 'https://api.openai.com/v1/chat/completions',
        ];
    }

    /**
     * @param array<int, array{role: string, content: string}> $messages
     */
    public static function streamOpenAiCompatible(
        array $llm,
        string $systemPrompt,
        array $messages,
        int $maxTokens = 2800
    ): void {
        $payload = [
            'model' => $llm['model'],
            'stream' => true,
            'temperature' => 0.5,
            'max_tokens' => $maxTokens,
            'messages' => array_merge(
                [['role' => 'system', 'content' => $systemPrompt]],
                array_map(static fn($m) => [
                    'role' => $m['role'] === 'assistant' ? 'assistant' : 'user',
                    'content' => $m['content'] ?? '',
                ], $messages)
            ),
        ];

        $body = Json::encode($payload);
        $url = $llm['url'];

        $lineBuffer = '';
        $wrote = false;
        $headersSent = false;
        $ensureHeaders = static function () use (&$headersSent): void {
            if ($headersSent) {
                return;
            }
            $headersSent = true;
            header('Content-Type: text/plain; charset=utf-8');
            header('Cache-Control: no-cache');
            if (function_exists('ob_flush')) {
                @ob_flush();
            }
            flush();
        };

        $ch = curl_init($url);
        CurlHelper::applySslOptions($ch);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $llm['apiKey'],
            ],
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_WRITEFUNCTION => static function ($ch, $chunk) use (&$lineBuffer, &$wrote, $ensureHeaders) {
                $lineBuffer .= $chunk;
                while (($pos = strpos($lineBuffer, "\n")) !== false) {
                    $line = substr($lineBuffer, 0, $pos);
                    $lineBuffer = substr($lineBuffer, $pos + 1);
                    $text = self::extractOpenAiDelta($line);
                    if ($text !== '') {
                        $wrote = true;
                        $ensureHeaders();
                        echo $text;
                        if (function_exists('ob_flush')) {
                            @ob_flush();
                        }
                        flush();
                    }
                }

                return strlen($chunk);
            },
            CURLOPT_TIMEOUT => 120,
        ]);

        $ok = curl_exec($ch);
        $error = curl_error($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        CurlHelper::close($ch);

        if ($ok === false) {
            throw new \RuntimeException($error ?: 'Ошибка запроса к LLM');
        }
        if ($lineBuffer !== '') {
            $text = self::extractOpenAiDelta($lineBuffer);
            if ($text !== '') {
                $wrote = true;
                $ensureHeaders();
                echo $text;
                if (function_exists('ob_flush')) {
                    @ob_flush();
                }
                flush();
            }
        }

        if ($status >= 400) {
            ApiErrorLog::write(Config::aiProvider(), 'chat.stream', $status, 'LLM HTTP error');
            throw new \RuntimeException("LLM HTTP {$status}");
        }

        if (!$wrote) {
            throw new \RuntimeException('Модель вернула пустой ответ. Попробуйте ещё раз.');
        }
    }

    private static function extractOpenAiDelta(string $line): string
    {
        $line = trim($line);
        if ($line === '' || strpos($line, 'data:') !== 0) {
            return '';
        }
        $data = trim(substr($line, 5));
        if ($data === '' || $data === '[DONE]') {
            return '';
        }
        try {
            $json = Json::decode($data);
        } catch (\Throwable $e) {
            return '';
        }

        return (string)($json['choices'][0]['delta']['content'] ?? '');
    }

    public static function isQuotaOrRateLimitError(\Throwable $err): bool
    {
        $raw = mb_strtolower($err->getMessage());

        return (bool)preg_match(
            '/\b429\b|\b402\b|quota|billing|insufficient balance|resource_exhausted|rate.?limit|too many requests|exceeded.*limit/i',
            $raw
        );
    }

    /**
     * Резервный LLM, если основной Gemini упёрся в квоту (нужен DEEPSEEK или OPENAI ключ).
     *
     * @return array{url: string, apiKey: string, model: string, provider: string}|null
     */
    public static function createFallbackLlm(): ?array
    {
        if (Config::aiProvider() !== 'gemini') {
            return null;
        }

        $deepseek = trim(Config::get('DEEPSEEK_API_KEY', ''));
        if ($deepseek !== '') {
            return [
                'provider' => 'deepseek',
                'apiKey' => $deepseek,
                'model' => Config::get('DEEPSEEK_MODEL', 'deepseek-chat'),
                'url' => 'https://api.deepseek.com/chat/completions',
            ];
        }

        $openai = trim(Config::get('OPENAI_API_KEY', ''));
        if ($openai !== '') {
            return [
                'provider' => 'openai',
                'apiKey' => $openai,
                'model' => Config::get('OPENAI_MODEL', 'gpt-4o-mini'),
                'url' => 'https://api.openai.com/v1/chat/completions',
            ];
        }

        return null;
    }

    public static function formatError(\Throwable $err): array
    {
        $raw = $err->getMessage();
        $provider = Config::aiProvider();

        if (strpos($raw, '403') !== false
            || preg_match('/has not been used in project|API has not been enabled|PERMISSION_DENIED/i', $raw)
        ) {
            return [
                'status' => 403,
                'code' => 'API_DISABLED',
                'error' => 'Gemini API не включён для этого ключа. Создайте ключ на https://aistudio.google.com/apikey',
            ];
        }

        if (self::isQuotaOrRateLimitError($err)) {
            $billingUrl = $provider === 'gemini'
                ? 'https://aistudio.google.com/apikey'
                : ($provider === 'deepseek'
                    ? 'https://platform.deepseek.com/top_up'
                    : 'https://platform.openai.com/settings/organization/billing');
            $name = $provider === 'gemini' ? 'Gemini' : ($provider === 'deepseek' ? 'DeepSeek' : 'OpenAI');
            $hint = preg_match('/rate.?limit|too many|429/i', $raw)
                ? ' Слишком много запросов подряд — подождите 30–60 сек. Голосовой ввод делает отдельный запрос на распознавание.'
                : '';
            return [
                'status' => 402,
                'code' => 'QUOTA_EXCEEDED',
                'error' => "Лимит или баланс {$name} исчерпан. Проверьте квоту: {$billingUrl}{$hint}",
            ];
        }

        if (strpos($raw, '401') !== false || preg_match('/invalid.*api.*key|incorrect api key/i', $raw)) {
            return [
                'status' => 401,
                'code' => 'INVALID_KEY',
                'error' => 'Неверный API-ключ. Проверьте настройки модуля AI-чат.',
            ];
        }

        return ['status' => 500, 'error' => $raw, 'code' => 'ERROR'];
    }
}
