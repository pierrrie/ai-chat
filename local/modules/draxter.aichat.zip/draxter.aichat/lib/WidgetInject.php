<?php

namespace Draxter\Aichat;

use Bitrix\Main\Loader;

class WidgetInject
{
    public static function onEpilog(): void
    {
        if (defined('ADMIN_SECTION') && ADMIN_SECTION === true) {
            return;
        }
        if (!Loader::includeModule('draxter.aichat')) {
            return;
        }
        if (!Settings::isWidgetEnabled() || Settings::get('WIDGET_AUTO_INJECT', 'N') !== 'Y') {
            return;
        }

        global $APPLICATION;
        if (!is_object($APPLICATION)) {
            return;
        }

        $APPLICATION->IncludeComponent(
            'draxter:aichat.chat',
            '',
            [],
            false,
            ['HIDE_ICONS' => 'Y']
        );
    }
}
