<?php

use Bitrix\Main\Config\Option;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use Draxter\Aichat\AdminStats;
use Draxter\Aichat\ApiErrorLog;
use Draxter\Aichat\Bitrix24Lead;
use Draxter\Aichat\Catalog;
use Draxter\Aichat\CrmFieldMapper;
use Draxter\Aichat\Settings;
use Draxter\Aichat\SiteConfig;

$moduleId = 'draxter.aichat';
Loader::includeModule($moduleId);
Loc::loadMessages(__FILE__);

$request = \Bitrix\Main\Context::getCurrent()->getRequest();
$configPath = SiteConfig::configPath();
$configLoaded = SiteConfig::isLoaded();
$siteId = (string)($_REQUEST['site_id'] ?? '');

global $draxter_aichat_default_option;

$textFields = [
    'AI_PROVIDER', 'GEMINI_API_KEY', 'GEMINI_MODEL', 'DEEPSEEK_API_KEY', 'DEEPSEEK_MODEL',
    'OPENAI_API_KEY', 'OPENAI_MODEL', 'CHAT_LOG_DIR', 'CHAT_WELCOME', 'CATALOG_SOURCE',
    'CATALOG_URL', 'CATALOG_PATH', 'CATALOG_IBLOCK_ID', 'CATALOG_REFRESH_MINUTES', 'CATALOG_PROFILE',
    'SHOP_NAME', 'SHOP_BRAND', 'SITE_URL', 'SHOP_SPECIALIZATION', 'BITRIX24_WEBHOOK_URL',
    'BITRIX24_ASSIGNED_ID', 'BITRIX24_SOURCE_ID', 'BITRIX24_SOURCE_LABEL', 'CRM_LEAD_TITLE_PREFIX',
    'CRM_EMAIL_TO',
    'YANDEX_METRIKA_COUNTER_ID', 'YANDEX_METRIKA_GOAL',
        'WIDGET_ACCENT_COLOR', 'WIDGET_FAB_RIGHT', 'WIDGET_FAB_BOTTOM',
        'WIDGET_AGENT_NAME', 'WIDGET_STATUS_TEXT',
    'VOICE_STT_PROVIDER', 'VOICE_GEMINI_STT_MODEL', 'VOICE_TTS_PROVIDER', 'VOICE_TTS_VOICE',
    'YANDEX_TTS_API_KEY', 'YANDEX_TTS_FOLDER_ID', 'YANDEX_TTS_VOICE',
    'VOICE_MAX_SECONDS', 'VOICE_TTS_MAX_CHARS',
    'RATE_LIMIT_PER_MINUTE', 'INTENT_SMALL_TALK_REGEX', 'INTENT_PRODUCT_KEYWORDS_REGEX',
    'INTENT_PURCHASE_INTENT_REGEX', 'INTENT_SHOPPING_INTENT_REGEX', 'INTENT_TOPIC_WORDS',
    'INTENT_MOTORCYCLE_QUERY_REGEX', 'INTENT_MOTORCYCLE_APPEND_KEYWORD',
];

$textareaFields = [
    'PROMPT_ROLE_LINE', 'PROMPT_SMALL_TALK_HINT', 'PROMPT_SEARCH_RULES', 'PROMPT_CATALOG_SYNONYMS',
    'PROMPT_STYLE_BRIEF', 'PROMPT_STYLE_DETAILED', 'PROMPT_RULES_COMMON', 'PROMPT_DOMAIN_RULES',
    'PROMPT_CATALOG_HEADER', 'PROMPT_LINK_RULES', 'PROMPT_FAQ_INTRO', 'PROMPT_FAQ_KNOWLEDGE',
    'MSG_LEAD_PHONE_CTA', 'MSG_LEAD_PHONE_CTA_PROMPT', 'MSG_PHONE_REPLY_OK', 'MSG_PHONE_REPLY_FALLBACK',
];

$flagFields = [
    'GEMINI_USE_VERTEX', 'CHAT_LOG_ENABLED', 'BITRIX24_LEAD_ENABLED', 'YANDEX_METRIKA_ENABLED', 'CURL_SSL_VERIFY',
    'WIDGET_ENABLED', 'WIDGET_AUTO_INJECT', 'WIDGET_SHOW_ONLINE', 'VOICE_ENABLED', 'VOICE_REPLY_ENABLED',
    'CRM_LOCAL_ENABLED', 'CRM_EMAIL_ENABLED',
];

$textareaFields[] = 'CRM_B24_FIELD_MAP';
$textareaFields[] = 'CRM_LOCAL_FIELD_MAP';

$saveOptions = static function (array $data) use ($moduleId, $siteId, $textFields, $textareaFields, $flagFields): void {
    foreach (array_merge($textFields, $textareaFields) as $name) {
        if (array_key_exists($name, $data)) {
            Option::set($moduleId, $name, (string)$data[$name], $siteId);
        }
    }
    foreach ($flagFields as $flag) {
        Option::set($moduleId, $flag, ($data[$flag] ?? '') === 'Y' ? 'Y' : 'N', $siteId);
    }
};

if ($request->isPost() && check_bitrix_sessid() && $request->getPost('import_from_config') === 'Y') {
    foreach (SiteConfig::exportFlatOptions() as $name => $value) {
        Option::set($moduleId, $name, $value, $siteId);
    }
    if ($request->getPost('refresh_catalog') === 'Y') {
        Catalog::refresh();
    }
    LocalRedirect($APPLICATION->GetCurPage() . '?mid=' . urlencode($moduleId) . '&lang=' . LANGUAGE_ID . '&site_id=' . urlencode($siteId) . '&imported=1');
}

if ($request->isPost() && check_bitrix_sessid() && $request->getPost('reset_defaults') === 'Y') {
    include __DIR__ . '/default_options.php';
    if (is_array($draxter_aichat_default_option)) {
        foreach ($draxter_aichat_default_option as $name => $value) {
            Option::set($moduleId, $name, (string)$value, $siteId);
        }
    }
    LocalRedirect($APPLICATION->GetCurPage() . '?mid=' . urlencode($moduleId) . '&lang=' . LANGUAGE_ID . '&site_id=' . urlencode($siteId) . '&reset=1');
}

if ($request->isPost() && check_bitrix_sessid() && $request->getPost('b24_map_template') === 'Y') {
    Option::set($moduleId, 'CRM_B24_FIELD_MAP', CrmFieldMapper::encodeMap(CrmFieldMapper::defaultB24Map()), $siteId);
    LocalRedirect($APPLICATION->GetCurPage() . '?mid=' . urlencode($moduleId) . '&lang=' . LANGUAGE_ID . '&site_id=' . urlencode($siteId) . '&saved=1');
}

if ($request->isPost() && check_bitrix_sessid() && $request->getPost('local_map_template') === 'Y') {
    Option::set($moduleId, 'CRM_LOCAL_FIELD_MAP', CrmFieldMapper::encodeMap(CrmFieldMapper::defaultLocalMap()), $siteId);
    LocalRedirect($APPLICATION->GetCurPage() . '?mid=' . urlencode($moduleId) . '&lang=' . LANGUAGE_ID . '&site_id=' . urlencode($siteId) . '&saved=1');
}

if ($request->isPost() && check_bitrix_sessid() && $request->getPost('b24_load_fields') === 'Y') {
    $_SESSION['DRAXTER_B24_FIELDS'] = implode(', ', Bitrix24Lead::fetchLeadFieldCodes());
    LocalRedirect($APPLICATION->GetCurPage() . '?mid=' . urlencode($moduleId) . '&lang=' . LANGUAGE_ID . '&site_id=' . urlencode($siteId) . '&b24fields=1');
}

if ($request->isPost() && check_bitrix_sessid() && $request->getPost('purge_api_logs') === 'Y') {
    $days = max(1, (int)$request->getPost('purge_days'));
    ApiErrorLog::purgeOlderThan($days);
    LocalRedirect($APPLICATION->GetCurPage() . '?mid=' . urlencode($moduleId) . '&lang=' . LANGUAGE_ID . '&site_id=' . urlencode($siteId) . '&purged=1');
}

if ($request->isPost() && check_bitrix_sessid() && $request->getPost('save') !== null) {
    $postData = $request->getPostList()->toArray();
    $saveOptions($postData);

    if (!empty($_FILES['AVATAR_FILE']['tmp_name']) && is_uploaded_file($_FILES['AVATAR_FILE']['tmp_name'])) {
        if (class_exists('CFile')) {
            $oldId = (int)Option::get($moduleId, 'AVATAR_FILE_ID', '', $siteId);
            $fileId = \CFile::SaveFile($_FILES['AVATAR_FILE'], 'draxter.aichat');
            if ($fileId) {
                Option::set($moduleId, 'AVATAR_FILE_ID', (string)(int)$fileId, $siteId);
                if ($oldId > 0) {
                    \CFile::Delete($oldId);
                }
            }
        }
    }
    if ($request->getPost('delete_avatar') === 'Y') {
        $oldId = (int)Option::get($moduleId, 'AVATAR_FILE_ID', '', $siteId);
        if ($oldId > 0 && class_exists('CFile')) {
            \CFile::Delete($oldId);
        }
        Option::set($moduleId, 'AVATAR_FILE_ID', '', $siteId);
    }

    if ($request->getPost('refresh_catalog') === 'Y') {
        Catalog::refresh();
    }

    LocalRedirect($APPLICATION->GetCurPage() . '?mid=' . urlencode($moduleId) . '&lang=' . LANGUAGE_ID . '&site_id=' . urlencode($siteId) . '&saved=1');
}

$tabControl = new CAdminTabControl('tabControl', [
    ['DIV' => 'edit_widget', 'TAB' => Loc::getMessage('DRAXTER_AICHAT_TAB_WIDGET') ?: 'Виджет', 'TITLE' => 'Внешний вид'],
    ['DIV' => 'edit_ai', 'TAB' => Loc::getMessage('DRAXTER_AICHAT_TAB_AI') ?: 'AI', 'TITLE' => 'Провайдер'],
    ['DIV' => 'edit_prompts', 'TAB' => Loc::getMessage('DRAXTER_AICHAT_TAB_PROMPTS') ?: 'Промпты', 'TITLE' => 'Системные промпты'],
    ['DIV' => 'edit_intent', 'TAB' => Loc::getMessage('DRAXTER_AICHAT_TAB_INTENT') ?: 'Намерения', 'TITLE' => 'Регулярные выражения'],
    ['DIV' => 'edit_voice', 'TAB' => Loc::getMessage('DRAXTER_AICHAT_TAB_VOICE') ?: 'Голос', 'TITLE' => 'Голосовой ввод и ответ'],
    ['DIV' => 'edit_catalog', 'TAB' => Loc::getMessage('DRAXTER_AICHAT_TAB_CATALOG') ?: 'Каталог', 'TITLE' => 'Товары'],
    ['DIV' => 'edit_crm', 'TAB' => Loc::getMessage('DRAXTER_AICHAT_TAB_CRM') ?: 'CRM', 'TITLE' => 'Лиды и поля CRM'],
    ['DIV' => 'edit_stats', 'TAB' => 'Статистика', 'TITLE' => 'Статистика чатов'],
    ['DIV' => 'edit_logs', 'TAB' => 'Логи', 'TITLE' => 'Логи API и сессий'],
]);

$statsDays = (int)($request->get('stats_days') ?: 7);
if (!in_array($statsDays, [7, 30], true)) {
    $statsDays = 7;
}
$statsData = AdminStats::aggregate($statsDays);
$logFilter = trim((string)$request->get('log_filter'));
$logFile = trim((string)$request->get('log_file'));
if ($logFile === '' && ApiErrorLog::listLogFiles() !== []) {
    $logFile = ApiErrorLog::listLogFiles()[0];
}
$logLines = $logFile !== '' ? ApiErrorLog::tailLines($logFile, 200, $logFilter !== '' ? $logFilter : null) : [];
$viewSessionId = trim((string)$request->get('view_session'));
$b24FieldCodesHint = (string)($_SESSION['DRAXTER_B24_FIELDS'] ?? '');

function draxter_aichat_opt(string $name, string $default = ''): string
{
    global $moduleId, $siteId;

    return htmlspecialcharsbx(Option::get($moduleId, $name, $default, $siteId));
}

function draxter_aichat_optarea(string $name, string $default = ''): string
{
    return htmlspecialcharsbx(draxter_aichat_opt_raw($name, $default));
}

function draxter_aichat_opt_raw(string $name, string $default = ''): string
{
    global $moduleId, $siteId;
    $v = Option::get($moduleId, $name, $default, $siteId);
    if ($v !== '') {
        return $v;
    }
    global $draxter_aichat_default_option;
    if (!isset($draxter_aichat_default_option)) {
        include __DIR__ . '/default_options.php';
    }

    return (string)($draxter_aichat_default_option[$name] ?? $default);
}

$ajaxHealthUrl = '/local/ajax/draxter_aichat.php?action=health';
$avatarId = (int)Option::get($moduleId, 'AVATAR_FILE_ID', '', $siteId);
$avatarPreview = '';
if ($avatarId > 0 && class_exists('CFile')) {
    $avatarPreview = (string)\CFile::GetPath($avatarId);
}

?>
<?php if ($request->get('imported') === '1'): ?>
<div class="adm-info-message-wrap adm-info-message-green"><div class="adm-info-message">
    Настройки импортированы из <code><?= htmlspecialcharsbx($configPath) ?></code>
</div></div>
<?php endif; ?>
<?php if ($request->get('saved') === '1'): ?>
<div class="adm-info-message-wrap adm-info-message-green"><div class="adm-info-message">Сохранено.</div></div>
<?php endif; ?>
<?php if ($request->get('reset') === '1'): ?>
<div class="adm-info-message-wrap adm-info-message-green"><div class="adm-info-message">Сброшено к значениям по умолчанию.</div></div>
<?php endif; ?>

<div class="adm-info-message-wrap">
    <div class="adm-info-message">
        <strong>Настройки сайта:</strong> приоритет у полей ниже (база). Файл
        <code><?= htmlspecialcharsbx($configPath) ?></code>
        <?= $configLoaded ? ' найден — подставляется только если поле выше пустое.' : ' не найден — все настройки в базе.' ?>
        <br>Подключение виджета: <code>&lt;?$APPLICATION-&gt;IncludeComponent('draxter:aichat.chat', '', []);?&gt;</code>
        в footer шаблона.
        <br><a href="<?= htmlspecialcharsbx($ajaxHealthUrl) ?>" target="_blank" rel="noopener">Проверка API (health)</a>
    </div>
</div>

<?php if (class_exists('CSite')): ?>
<form method="get" style="margin-bottom:12px">
    <input type="hidden" name="mid" value="<?= htmlspecialcharsbx($moduleId) ?>">
    <input type="hidden" name="lang" value="<?= LANGUAGE_ID ?>">
    <label>Сайт (мультисайт): </label>
    <select name="site_id" onchange="this.form.submit()">
        <option value="">— по умолчанию —</option>
        <?php
        $rs = \CSite::GetList('sort', 'asc', ['ACTIVE' => 'Y']);
        while ($site = $rs->Fetch()):
            ?>
            <option value="<?= htmlspecialcharsbx($site['LID']) ?>" <?= $siteId === $site['LID'] ? 'selected' : '' ?>>
                [<?= htmlspecialcharsbx($site['LID']) ?>] <?= htmlspecialcharsbx($site['NAME']) ?>
            </option>
        <?php endwhile; ?>
    </select>
</form>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" action="<?= $APPLICATION->GetCurPage() ?>?mid=<?= urlencode($moduleId) ?>&lang=<?= LANGUAGE_ID ?>&site_id=<?= urlencode($siteId) ?>">
    <?= bitrix_sessid_post() ?>
    <input type="hidden" name="site_id" value="<?= htmlspecialcharsbx($siteId) ?>">

    <?php $tabControl->Begin(); ?>

    <?php $tabControl->BeginNextTab(); ?>
    <tr><td width="35%">Показывать виджет</td><td><input type="checkbox" name="WIDGET_ENABLED" value="Y" <?= draxter_aichat_opt('WIDGET_ENABLED', 'Y') === 'Y' ? 'checked' : '' ?>></td></tr>
    <tr><td>Приветствие</td><td><textarea name="CHAT_WELCOME" rows="3" cols="70"><?= draxter_aichat_optarea('CHAT_WELCOME') ?></textarea></td></tr>
    <tr><td>Аватар (PNG/JPG)</td><td>
        <?php if ($avatarPreview !== ''): ?><img src="<?= htmlspecialcharsbx($avatarPreview) ?>" alt="" style="max-height:48px;display:block;margin-bottom:8px"><?php endif; ?>
        <input type="file" name="AVATAR_FILE" accept="image/*">
        <label><input type="checkbox" name="delete_avatar" value="Y"> Удалить текущий</label>
    </td></tr>
    <tr><td>Цвет акцента</td><td><input type="text" name="WIDGET_ACCENT_COLOR" value="<?= draxter_aichat_opt('WIDGET_ACCENT_COLOR', '#2563eb') ?>" size="12" placeholder="#2563eb"></td></tr>
    <tr><td>Отступ FAB справа (px)</td><td><input type="text" name="WIDGET_FAB_RIGHT" value="<?= draxter_aichat_opt('WIDGET_FAB_RIGHT', '24') ?>" size="6"></td></tr>
    <tr><td>Отступ FAB снизу (px)</td><td><input type="text" name="WIDGET_FAB_BOTTOM" value="<?= draxter_aichat_opt('WIDGET_FAB_BOTTOM', '24') ?>" size="6"></td></tr>
    <tr><td>Имя консультанта</td><td><input type="text" name="WIDGET_AGENT_NAME" value="<?= draxter_aichat_opt('WIDGET_AGENT_NAME') ?>" size="40" placeholder="пусто = название магазина"></td></tr>
    <tr><td>Показывать статус «онлайн»</td><td><input type="checkbox" name="WIDGET_SHOW_ONLINE" value="Y" <?= draxter_aichat_opt('WIDGET_SHOW_ONLINE', 'Y') === 'Y' ? 'checked' : '' ?>></td></tr>
    <tr><td>Текст статуса</td><td><input type="text" name="WIDGET_STATUS_TEXT" value="<?= draxter_aichat_opt('WIDGET_STATUS_TEXT', 'Онлайн • отвечает сразу') ?>" size="50" placeholder="Онлайн • отвечает сразу"></td></tr>
    <tr><td>Автоподключение на всех страницах</td><td><input type="checkbox" name="WIDGET_AUTO_INJECT" value="Y" <?= draxter_aichat_opt('WIDGET_AUTO_INJECT', 'N') === 'Y' ? 'checked' : '' ?>><br><small>Через OnEpilog (без правки шаблона)</small></td></tr>

    <?php $tabControl->BeginNextTab(); ?>
    <tr><td>Провайдер</td><td>
        <select name="AI_PROVIDER">
            <option value="gemini" <?= draxter_aichat_opt('AI_PROVIDER', 'gemini') === 'gemini' ? 'selected' : '' ?>>Gemini</option>
            <option value="deepseek" <?= draxter_aichat_opt('AI_PROVIDER') === 'deepseek' ? 'selected' : '' ?>>DeepSeek</option>
            <option value="openai" <?= draxter_aichat_opt('AI_PROVIDER') === 'openai' ? 'selected' : '' ?>>OpenAI</option>
        </select>
    </td></tr>
    <tr><td>GEMINI_API_KEY</td><td><input type="password" name="GEMINI_API_KEY" value="<?= draxter_aichat_opt('GEMINI_API_KEY') ?>" size="60" autocomplete="off"></td></tr>
    <tr><td>GEMINI_MODEL</td><td><input type="text" name="GEMINI_MODEL" value="<?= draxter_aichat_opt('GEMINI_MODEL', 'gemini-2.5-flash') ?>" size="40"></td></tr>
    <tr><td>GEMINI_USE_VERTEX</td><td><input type="checkbox" name="GEMINI_USE_VERTEX" value="Y" <?= draxter_aichat_opt('GEMINI_USE_VERTEX', 'N') === 'Y' ? 'checked' : '' ?>></td></tr>
    <tr><td>DEEPSEEK_API_KEY</td><td><input type="password" name="DEEPSEEK_API_KEY" value="<?= draxter_aichat_opt('DEEPSEEK_API_KEY') ?>" size="60" autocomplete="off"></td></tr>
    <tr><td>DEEPSEEK_MODEL</td><td><input type="text" name="DEEPSEEK_MODEL" value="<?= draxter_aichat_opt('DEEPSEEK_MODEL', 'deepseek-chat') ?>" size="40"></td></tr>
    <tr><td>OPENAI_API_KEY</td><td><input type="password" name="OPENAI_API_KEY" value="<?= draxter_aichat_opt('OPENAI_API_KEY') ?>" size="60" autocomplete="off"><br><small>Нужен для Whisper/TTS при голосовом режиме</small></td></tr>
    <tr><td>OPENAI_MODEL</td><td><input type="text" name="OPENAI_MODEL" value="<?= draxter_aichat_opt('OPENAI_MODEL', 'gpt-4o-mini') ?>" size="40"></td></tr>
    <tr><td>Проверка SSL (curl)</td><td><input type="checkbox" name="CURL_SSL_VERIFY" value="Y" <?= draxter_aichat_opt('CURL_SSL_VERIFY', 'Y') === 'Y' ? 'checked' : '' ?>></td></tr>

    <?php $tabControl->BeginNextTab(); ?>
    <tr><td colspan="2"><em>Плейсхолдеры: {shop_name}, {brand}</em></td></tr>
    <tr><td>Роль (role_line)</td><td><textarea name="PROMPT_ROLE_LINE" rows="2" cols="70"><?= draxter_aichat_optarea('PROMPT_ROLE_LINE') ?></textarea></td></tr>
    <tr><td>Small talk</td><td><textarea name="PROMPT_SMALL_TALK_HINT" rows="2" cols="70"><?= draxter_aichat_optarea('PROMPT_SMALL_TALK_HINT') ?></textarea></td></tr>
    <tr><td>Правила подбора</td><td><textarea name="PROMPT_SEARCH_RULES" rows="6" cols="70"><?= draxter_aichat_optarea('PROMPT_SEARCH_RULES') ?></textarea></td></tr>
    <tr><td>Синонимы каталога</td><td><input type="text" name="PROMPT_CATALOG_SYNONYMS" value="<?= draxter_aichat_opt('PROMPT_CATALOG_SYNONYMS') ?>" size="70"></td></tr>
    <tr><td>Стиль краткий</td><td><textarea name="PROMPT_STYLE_BRIEF" rows="3" cols="70"><?= draxter_aichat_optarea('PROMPT_STYLE_BRIEF') ?></textarea></td></tr>
    <tr><td>Стиль подробный</td><td><textarea name="PROMPT_STYLE_DETAILED" rows="3" cols="70"><?= draxter_aichat_optarea('PROMPT_STYLE_DETAILED') ?></textarea></td></tr>
    <tr><td>Общие правила</td><td><textarea name="PROMPT_RULES_COMMON" rows="2" cols="70"><?= draxter_aichat_optarea('PROMPT_RULES_COMMON') ?></textarea></td></tr>
    <tr><td>Правила ссылок</td><td><textarea name="PROMPT_LINK_RULES" rows="2" cols="70"><?= draxter_aichat_optarea('PROMPT_LINK_RULES') ?></textarea></td></tr>
    <tr><td>Заголовок каталога</td><td><input type="text" name="PROMPT_CATALOG_HEADER" value="<?= draxter_aichat_opt('PROMPT_CATALOG_HEADER') ?>" size="70"></td></tr>
    <tr><td>Доменные правила (по строке)</td><td><textarea name="PROMPT_DOMAIN_RULES" rows="4" cols="70"><?= draxter_aichat_optarea('PROMPT_DOMAIN_RULES') ?></textarea></td></tr>
    <tr><td colspan="2"><strong>Справочник ответов (FAQ)</strong> — доставка, оплата, дилеры, техника вне каталога</td></tr>
    <tr><td>Инструкция для AI</td><td><textarea name="PROMPT_FAQ_INTRO" rows="3" cols="70"><?= draxter_aichat_optarea('PROMPT_FAQ_INTRO') ?></textarea></td></tr>
    <tr><td>Справочник (блоки)</td><td>
        <textarea name="PROMPT_FAQ_KNOWLEDGE" rows="22" cols="70" style="font-family:monospace;font-size:12px"><?= draxter_aichat_optarea('PROMPT_FAQ_KNOWLEDGE') ?></textarea>
        <p class="adm-info-message-wrap" style="max-width:720px;margin-top:8px">
            Формат каждого ответа:<br>
            <code># keywords: доставка, город, срок</code><br>
            <code># title: Доставка</code> (необязательно)<br>
            Текст ответа (что должен сказать консультант).<br>
            Пустая строка между блоками. По ключевым словам в вопросе клиента подставляются нужные блоки; если совпадений нет — весь справочник.
        </p>
    </td></tr>
    <tr><td colspan="2"><strong>Превью FAQ</strong></td></tr>
    <tr><td>Тестовый вопрос</td><td>
        <input type="text" id="draxter-faq-question" size="60" placeholder="Например: срок доставки в Йошкар-Олу">
        <button type="button" class="adm-btn" id="draxter-faq-preview-btn">Проверить FAQ</button>
        <pre id="draxter-faq-preview-out" style="max-width:720px;white-space:pre-wrap;margin-top:8px;background:#f5f5f5;padding:8px;display:none"></pre>
    </td></tr>

    <?php $tabControl->BeginNextTab(); ?>
    <tr><td>Small talk regex</td><td><input type="text" name="INTENT_SMALL_TALK_REGEX" value="<?= draxter_aichat_opt('INTENT_SMALL_TALK_REGEX') ?>" size="70"></td></tr>
    <tr><td>Ключевые слова товара</td><td><input type="text" name="INTENT_PRODUCT_KEYWORDS_REGEX" value="<?= draxter_aichat_opt('INTENT_PRODUCT_KEYWORDS_REGEX') ?>" size="70"></td></tr>
    <tr><td>Намерение покупки</td><td><input type="text" name="INTENT_PURCHASE_INTENT_REGEX" value="<?= draxter_aichat_opt('INTENT_PURCHASE_INTENT_REGEX') ?>" size="70"></td></tr>
    <tr><td>Шоппинг intent</td><td><input type="text" name="INTENT_SHOPPING_INTENT_REGEX" value="<?= draxter_aichat_opt('INTENT_SHOPPING_INTENT_REGEX') ?>" size="70"></td></tr>
    <tr><td>Тематические слова</td><td><input type="text" name="INTENT_TOPIC_WORDS" value="<?= draxter_aichat_opt('INTENT_TOPIC_WORDS') ?>" size="70" placeholder="слова через запятую"></td></tr>
    <tr><td>Moto query regex</td><td><input type="text" name="INTENT_MOTORCYCLE_QUERY_REGEX" value="<?= draxter_aichat_opt('INTENT_MOTORCYCLE_QUERY_REGEX') ?>" size="70"></td></tr>
    <tr><td>Moto append keyword</td><td><input type="text" name="INTENT_MOTORCYCLE_APPEND_KEYWORD" value="<?= draxter_aichat_opt('INTENT_MOTORCYCLE_APPEND_KEYWORD', 'мотоцикл') ?>" size="20"></td></tr>

    <?php $tabControl->BeginNextTab(); ?>
    <tr><td>Голосовой ввод</td><td><input type="checkbox" name="VOICE_ENABLED" value="Y" <?= draxter_aichat_opt('VOICE_ENABLED', 'N') === 'Y' ? 'checked' : '' ?>></td></tr>
    <tr><td>Отвечать голосом</td><td><input type="checkbox" name="VOICE_REPLY_ENABLED" value="Y" <?= draxter_aichat_opt('VOICE_REPLY_ENABLED', 'N') === 'Y' ? 'checked' : '' ?>></td></tr>
    <tr><td>TTS провайдер</td><td>
        <select name="VOICE_TTS_PROVIDER">
            <?php foreach (['browser' => 'Браузер (speechSynthesis)', 'yandex' => 'Yandex SpeechKit', 'openai' => 'OpenAI TTS'] as $val => $label): ?>
                <option value="<?= $val ?>" <?= draxter_aichat_opt('VOICE_TTS_PROVIDER', 'browser') === $val ? 'selected' : '' ?>><?= htmlspecialcharsbx($label) ?></option>
            <?php endforeach; ?>
        </select>
    </td></tr>
    <tr><td>Yandex TTS API Key</td><td><input type="password" name="YANDEX_TTS_API_KEY" value="<?= draxter_aichat_opt('YANDEX_TTS_API_KEY') ?>" size="60" autocomplete="off"></td></tr>
    <tr><td>Yandex Folder ID</td><td><input type="text" name="YANDEX_TTS_FOLDER_ID" value="<?= draxter_aichat_opt('YANDEX_TTS_FOLDER_ID') ?>" size="40"></td></tr>
    <tr><td>Yandex голос</td><td><input type="text" name="YANDEX_TTS_VOICE" value="<?= draxter_aichat_opt('YANDEX_TTS_VOICE', 'jane') ?>" size="20" placeholder="jane"></td></tr>
    <tr><td>STT провайдер</td><td>
        <select name="VOICE_STT_PROVIDER">
            <?php foreach (['auto', 'openai', 'gemini'] as $p): ?>
                <option value="<?= $p ?>" <?= draxter_aichat_opt('VOICE_STT_PROVIDER', 'auto') === $p ? 'selected' : '' ?>><?= $p ?></option>
            <?php endforeach; ?>
        </select>
    </td></tr>
    <tr><td>Gemini STT модель</td><td><input type="text" name="VOICE_GEMINI_STT_MODEL" value="<?= draxter_aichat_opt('VOICE_GEMINI_STT_MODEL') ?>" size="28" placeholder="пусто = GEMINI_MODEL"> <span class="adm-info-message-wrap">Для Vertex укажите ту же модель, что в чате (<code>gemini-2.5-flash</code>). Пустое поле = модель чата. При 404 модуль пробует другие версии автоматически.</span></td></tr>
    <tr><td>Голос TTS (OpenAI)</td><td>
        <small>При провайдере OpenAI</small><br>
        <select name="VOICE_TTS_VOICE">
            <?php foreach (['alloy', 'echo', 'fable', 'onyx', 'nova', 'shimmer'] as $v): ?>
                <option value="<?= $v ?>" <?= draxter_aichat_opt('VOICE_TTS_VOICE', 'alloy') === $v ? 'selected' : '' ?>><?= $v ?></option>
            <?php endforeach; ?>
        </select>
    </td></tr>
    <tr><td>Макс. длительность записи (с)</td><td><input type="text" name="VOICE_MAX_SECONDS" value="<?= draxter_aichat_opt('VOICE_MAX_SECONDS', '60') ?>" size="6"></td></tr>
    <tr><td>Макс. символов для TTS</td><td><input type="text" name="VOICE_TTS_MAX_CHARS" value="<?= draxter_aichat_opt('VOICE_TTS_MAX_CHARS', '500') ?>" size="6"></td></tr>

    <?php $tabControl->BeginNextTab(); ?>
    <tr><td>Источник</td><td>
        <select name="CATALOG_SOURCE">
            <option value="yml_url" <?= draxter_aichat_opt('CATALOG_SOURCE', 'yml_url') === 'yml_url' ? 'selected' : '' ?>>YML по URL</option>
            <option value="yml_file" <?= draxter_aichat_opt('CATALOG_SOURCE') === 'yml_file' ? 'selected' : '' ?>>YML файл</option>
            <option value="iblock" <?= draxter_aichat_opt('CATALOG_SOURCE') === 'iblock' ? 'selected' : '' ?>>Инфоблок</option>
        </select>
    </td></tr>
    <tr><td>CATALOG_URL</td><td><input type="text" name="CATALOG_URL" value="<?= draxter_aichat_opt('CATALOG_URL', '/bitrix/catalog_export/catalog.xml') ?>" size="70"></td></tr>
    <tr><td>CATALOG_PATH</td><td><input type="text" name="CATALOG_PATH" value="<?= draxter_aichat_opt('CATALOG_PATH') ?>" size="70"></td></tr>
    <tr><td>Инфоблок ID</td><td>
        <input type="text" name="CATALOG_IBLOCK_ID" value="<?= draxter_aichat_opt('CATALOG_IBLOCK_ID') ?>" size="10">
        <?php if (class_exists('CIBlock') && Loader::includeModule('iblock')): ?>
            <select onchange="document.querySelector('[name=CATALOG_IBLOCK_ID]').value=this.value">
                <option value="">— выбрать —</option>
                <?php
                $ibRes = \CIBlock::GetList(['SORT' => 'ASC'], ['ACTIVE' => 'Y']);
                while ($ib = $ibRes->Fetch()):
                    ?>
                    <option value="<?= (int)$ib['ID'] ?>">[<?= (int)$ib['ID'] ?>] <?= htmlspecialcharsbx($ib['NAME']) ?></option>
                <?php endwhile; ?>
            </select>
        <?php endif; ?>
    </td></tr>
    <tr><td>Профиль каталога</td><td>
        <select name="CATALOG_PROFILE">
            <?php foreach (['auto', 'garden', 'full'] as $p): ?>
                <option value="<?= $p ?>" <?= draxter_aichat_opt('CATALOG_PROFILE', 'auto') === $p ? 'selected' : '' ?>><?= $p ?></option>
            <?php endforeach; ?>
        </select>
    </td></tr>
    <tr><td>Кэш (мин)</td><td><input type="text" name="CATALOG_REFRESH_MINUTES" value="<?= draxter_aichat_opt('CATALOG_REFRESH_MINUTES', '60') ?>" size="10"></td></tr>
    <tr><td colspan="2"><label><input type="checkbox" name="refresh_catalog" value="Y"> Сбросить кэш при сохранении</label></td></tr>

    <?php $tabControl->BeginNextTab(); ?>
    <tr><td>Название магазина</td><td><input type="text" name="SHOP_NAME" value="<?= draxter_aichat_opt('SHOP_NAME', 'Магазин') ?>" size="40"></td></tr>
    <tr><td>Бренд</td><td><input type="text" name="SHOP_BRAND" value="<?= draxter_aichat_opt('SHOP_BRAND') ?>" size="40" placeholder="пусто = название"></td></tr>
    <tr><td>SITE_URL</td><td><input type="text" name="SITE_URL" value="<?= draxter_aichat_opt('SITE_URL') ?>" size="50"></td></tr>
    <tr><td>Специализация</td><td><input type="text" name="SHOP_SPECIALIZATION" value="<?= draxter_aichat_opt('SHOP_SPECIALIZATION') ?>" size="70"></td></tr>
    <tr><td>Лимит запросов/мин (IP)</td><td><input type="text" name="RATE_LIMIT_PER_MINUTE" value="<?= draxter_aichat_opt('RATE_LIMIT_PER_MINUTE', '60') ?>" size="6"> (0 = без лимита)</td></tr>
    <tr><td colspan="2"><strong>Каналы лидов</strong></td></tr>
    <tr><td colspan="2"><em>Можно включить несколько каналов одновременно. Ошибка одного канала не блокирует остальные.</em></td></tr>
    <tr><td colspan="2"><strong>Bitrix24 (облако)</strong></td></tr>
    <tr><td>Создавать лиды</td><td><input type="checkbox" name="BITRIX24_LEAD_ENABLED" value="Y" <?= draxter_aichat_opt('BITRIX24_LEAD_ENABLED', 'Y') === 'Y' ? 'checked' : '' ?>></td></tr>
    <tr><td>Webhook</td><td><input type="text" name="BITRIX24_WEBHOOK_URL" value="<?= draxter_aichat_opt('BITRIX24_WEBHOOK_URL') ?>" size="70"></td></tr>
    <tr><td>Ответственный ID</td><td><input type="text" name="BITRIX24_ASSIGNED_ID" value="<?= draxter_aichat_opt('BITRIX24_ASSIGNED_ID', '1') ?>" size="10"></td></tr>
    <tr><td>SOURCE_ID (запасной)</td><td><input type="text" name="BITRIX24_SOURCE_ID" value="<?= draxter_aichat_opt('BITRIX24_SOURCE_ID', 'aichat') ?>" size="20" placeholder="UC_…"> <span class="adm-info-message-wrap">Используется, если в CRM нет источника с именем из поля ниже. Поле «Источник» в лиде — <strong>название</strong> из справочника CRM → Источники, не домен.</span></td></tr>
    <tr><td>Имя источника в CRM</td><td><input type="text" name="BITRIX24_SOURCE_LABEL" value="<?= draxter_aichat_opt('BITRIX24_SOURCE_LABEL', 'aichat') ?>" size="20" placeholder="aichat"> <span class="adm-info-message-wrap">Модуль ищет источник с таким <strong>названием</strong> (например <code>aichat</code>). Если у кода <code>UC_…</code> название «draxter.ru» — переименуйте в CRM или создайте источник «aichat».</span></td></tr>
    <tr><td>Префикс лида</td><td><input type="text" name="CRM_LEAD_TITLE_PREFIX" value="<?= draxter_aichat_opt('CRM_LEAD_TITLE_PREFIX', 'AI-чат') ?>" size="30"></td></tr>
    <tr><td>Маппинг полей B24 (JSON)</td><td>
        <textarea name="CRM_B24_FIELD_MAP" rows="12" cols="70" style="font-family:monospace;font-size:12px"><?= draxter_aichat_optarea('CRM_B24_FIELD_MAP') ?></textarea>
        <p><code>[{"field":"UF_CRM_…","source":"page_url"}, …]</code> — источники: phone, name, comment, page_url, page_title, http_referer, utm_*, session_id, products, site_url, source_label, source_id</p>
        <button type="submit" name="b24_map_template" value="Y" class="adm-btn">Подставить шаблон Draxter</button>
        <button type="submit" name="b24_load_fields" value="Y" class="adm-btn">Загрузить коды полей из Bitrix24</button>
        <?php if ($b24FieldCodesHint !== ''): ?>
            <p class="adm-info-message-wrap" style="max-width:720px;margin-top:8px"><small><?= htmlspecialcharsbx(mb_substr($b24FieldCodesHint, 0, 2000)) ?></small></p>
        <?php endif; ?>
    </td></tr>
    <tr><td colspan="2"><strong>CRM сайта (модуль crm)</strong></td></tr>
    <tr><td>Создавать лид в CRM сайта</td><td><input type="checkbox" name="CRM_LOCAL_ENABLED" value="Y" <?= draxter_aichat_opt('CRM_LOCAL_ENABLED', 'N') === 'Y' ? 'checked' : '' ?>></td></tr>
    <tr><td>Маппинг локального CRM (JSON)</td><td>
        <textarea name="CRM_LOCAL_FIELD_MAP" rows="8" cols="70" style="font-family:monospace;font-size:12px"><?= draxter_aichat_optarea('CRM_LOCAL_FIELD_MAP') ?></textarea>
        <button type="submit" name="local_map_template" value="Y" class="adm-btn">Шаблон локального CRM</button>
    </td></tr>
    <tr><td colspan="2"><strong>Email</strong></td></tr>
    <tr><td>Отправлять лид на почту</td><td><input type="checkbox" name="CRM_EMAIL_ENABLED" value="Y" <?= draxter_aichat_opt('CRM_EMAIL_ENABLED', 'N') === 'Y' ? 'checked' : '' ?>></td></tr>
    <tr><td>Адреса (через запятую)</td><td><input type="text" name="CRM_EMAIL_TO" value="<?= draxter_aichat_opt('CRM_EMAIL_TO') ?>" size="60" placeholder="manager@example.com"></td></tr>
    <tr><td colspan="2"><strong>Яндекс.Метрика</strong> (цель при успешном создании лида)</td></tr>
    <tr><td>Отправлять цель</td><td><input type="checkbox" name="YANDEX_METRIKA_ENABLED" value="Y" <?= draxter_aichat_opt('YANDEX_METRIKA_ENABLED', 'Y') === 'Y' ? 'checked' : '' ?>></td></tr>
    <tr><td>Номер счётчика</td><td><input type="text" name="YANDEX_METRIKA_COUNTER_ID" value="<?= draxter_aichat_opt('YANDEX_METRIKA_COUNTER_ID', '90547846') ?>" size="12" placeholder="90547846"></td></tr>
    <tr><td>Идентификатор цели</td><td><input type="text" name="YANDEX_METRIKA_GOAL" value="<?= draxter_aichat_opt('YANDEX_METRIKA_GOAL', 'aibot') ?>" size="20" placeholder="aibot"> <span class="adm-info-message-wrap">Вызов <code>ym(счётчик,'reachGoal',цель)</code> на сайте, где уже подключена Метрика.</span></td></tr>
    <tr><td colspan="2"><strong>Сообщения CRM</strong></td></tr>
    <tr><td>CTA телефон</td><td><textarea name="MSG_LEAD_PHONE_CTA" rows="2" cols="70"><?= draxter_aichat_optarea('MSG_LEAD_PHONE_CTA') ?></textarea></td></tr>
    <tr><td>CTA в промпте</td><td><textarea name="MSG_LEAD_PHONE_CTA_PROMPT" rows="2" cols="70"><?= draxter_aichat_optarea('MSG_LEAD_PHONE_CTA_PROMPT') ?></textarea></td></tr>
    <tr><td>Ответ при номере OK</td><td><textarea name="MSG_PHONE_REPLY_OK" rows="2" cols="70"><?= draxter_aichat_optarea('MSG_PHONE_REPLY_OK') ?></textarea></td></tr>
    <tr><td>Ответ при номере fallback</td><td><textarea name="MSG_PHONE_REPLY_FALLBACK" rows="2" cols="70"><?= draxter_aichat_optarea('MSG_PHONE_REPLY_FALLBACK') ?></textarea></td></tr>

    <?php $tabControl->BeginNextTab(); ?>
    <tr><td colspan="2">
        <a href="?mid=<?= urlencode($moduleId) ?>&lang=<?= LANGUAGE_ID ?>&site_id=<?= urlencode($siteId) ?>&stats_days=7">7 дней</a>
        | <a href="?mid=<?= urlencode($moduleId) ?>&lang=<?= LANGUAGE_ID ?>&site_id=<?= urlencode($siteId) ?>&stats_days=30">30 дней</a>
    </td></tr>
    <tr><td>Сессий</td><td><?= (int)$statsData['sessions'] ?></td></tr>
    <tr><td>Сообщений (ходов)</td><td><?= (int)$statsData['messages'] ?></td></tr>
    <tr><td>Ошибок API в логах</td><td><?= (int)$statsData['errors'] ?></td></tr>
    <tr><td>Лидов</td><td><?= (int)$statsData['leads'] ?></td></tr>
    <tr><td>Топ фраз пользователя</td><td>
        <?php if ($statsData['topPhrases'] === []): ?>
            <em>Нет данных</em>
        <?php else: ?>
            <ol><?php foreach ($statsData['topPhrases'] as $row): ?>
                <li><?= htmlspecialcharsbx($row['phrase']) ?> (<?= (int)$row['count'] ?>)</li>
            <?php endforeach; ?></ol>
        <?php endif; ?>
    </td></tr>
    <tr><td>Последние диалоги</td><td>
        <table class="internal" style="width:100%">
            <tr><th>Дата</th><th>Сессия</th><th>Тел.</th><th>Ходов</th><th></th></tr>
            <?php foreach ($statsData['recent'] as $row): ?>
                <tr>
                    <td><?= htmlspecialcharsbx($row['date']) ?></td>
                    <td><code><?= htmlspecialcharsbx($row['sessionId']) ?></code></td>
                    <td><?= htmlspecialcharsbx($row['phone'] ?? '—') ?></td>
                    <td><?= (int)$row['turns'] ?><?= !empty($row['error']) ? ' ⚠' : '' ?></td>
                    <td><a href="?mid=<?= urlencode($moduleId) ?>&lang=<?= LANGUAGE_ID ?>&site_id=<?= urlencode($siteId) ?>&view_session=<?= urlencode($row['sessionId']) ?>#edit_logs">лог</a></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </td></tr>

    <?php $tabControl->BeginNextTab(); ?>
    <tr><td>Включить логи сессий</td><td><input type="checkbox" name="CHAT_LOG_ENABLED" value="Y" <?= draxter_aichat_opt('CHAT_LOG_ENABLED', 'Y') === 'Y' ? 'checked' : '' ?>></td></tr>
    <tr><td>Папка логов</td><td><input type="text" name="CHAT_LOG_DIR" value="<?= draxter_aichat_opt('CHAT_LOG_DIR') ?>" size="60" placeholder="/upload/draxter_aichat_logs"></td></tr>
    <tr><td>Лог API</td><td>
        <p>
            <?php foreach (ApiErrorLog::listLogFiles() as $f): ?>
                <a href="<?= $APPLICATION->GetCurPage() ?>?mid=<?= urlencode($moduleId) ?>&lang=<?= LANGUAGE_ID ?>&site_id=<?= urlencode($siteId) ?>&log_file=<?= urlencode($f) ?><?= $logFilter !== '' ? '&log_filter=' . urlencode($logFilter) : '' ?>#edit_logs"><?= htmlspecialcharsbx(basename($f)) ?></a>
                &nbsp;
            <?php endforeach; ?>
        </p>
        <p>Фильтр в URL: <code>?log_filter=error</code> (подстрока в строке)</p>
        <pre style="max-height:400px;overflow:auto;background:#1e1e1e;color:#ddd;padding:8px;font-size:11px"><?php
            foreach ($logLines as $line) {
                echo htmlspecialcharsbx($line) . "\n";
            }
        ?></pre>
        <p><em>Очистка старых api-логов — форма ниже страницы настроек.</em></p>
    </td></tr>
    <?php if ($viewSessionId !== ''): ?>
    <tr><td>Сессия <?= htmlspecialcharsbx($viewSessionId) ?></td><td>
        <pre style="max-height:500px;overflow:auto;white-space:pre-wrap;background:#f8f8f8;padding:8px"><?= htmlspecialcharsbx(AdminStats::formatSessionForAdmin($viewSessionId)) ?></pre>
    </td></tr>
    <?php endif; ?>

    <?php $tabControl->Buttons(); ?>
    <input type="submit" name="save" value="Сохранить" class="adm-btn-save">
    <input type="submit" name="reset_defaults" value="Сбросить к умолчанию" class="adm-btn" onclick="return confirm('Сбросить все настройки этого сайта?');">
    <?php $tabControl->End(); ?>
</form>

<form method="post" style="margin-top:16px" action="<?= $APPLICATION->GetCurPage() ?>?mid=<?= urlencode($moduleId) ?>&lang=<?= LANGUAGE_ID ?>&site_id=<?= urlencode($siteId) ?>" onsubmit="return confirm('Удалить старые api-*.log?');">
    <?= bitrix_sessid_post() ?>
    <input type="hidden" name="site_id" value="<?= htmlspecialcharsbx($siteId) ?>">
    <input type="hidden" name="purge_api_logs" value="Y">
    Удалить api-логи старше <input type="number" name="purge_days" value="30" size="4" min="1"> дней
    <input type="submit" value="Очистить api-логи" class="adm-btn">
</form>

<form method="post" style="margin-top:16px" action="<?= $APPLICATION->GetCurPage() ?>?mid=<?= urlencode($moduleId) ?>&lang=<?= LANGUAGE_ID ?>&site_id=<?= urlencode($siteId) ?>">
    <?= bitrix_sessid_post() ?>
    <label><input type="checkbox" name="import_from_config" value="Y"> Импортировать из <code>aichat.config.php</code> в базу</label>
    <label><input type="checkbox" name="refresh_catalog" value="Y"> + сбросить кэш каталога</label>
    <input type="submit" value="Импорт" class="adm-btn">
</form>

<script>
(function () {
    var btn = document.getElementById('draxter-faq-preview-btn');
    if (!btn) return;
    btn.addEventListener('click', function () {
        var q = document.getElementById('draxter-faq-question');
        var out = document.getElementById('draxter-faq-preview-out');
        if (!q || !out) return;
        out.style.display = 'block';
        out.textContent = 'Загрузка…';
        fetch('/local/ajax/draxter_aichat.php?action=faq_preview', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                question: q.value,
                sessid: '<?= bitrix_sessid() ?>'
            })
        }).then(function (r) { return r.json(); }).then(function (data) {
            if (data.error) {
                out.textContent = data.error;
                return;
            }
            var lines = ['Подобранные секции:'];
            (data.matched || []).forEach(function (m) {
                lines.push('- ' + (m.title || '(без заголовка)') + ' [' + (m.keywords || []).join(', ') + ']');
            });
            lines.push('', '--- Фрагмент для промпта ---', data.promptSection || '');
            out.textContent = lines.join('\n');
        }).catch(function (e) {
            out.textContent = e.message || 'Ошибка запроса';
        });
    });
})();
</script>
