<?php

$draxter_aichat_default_option = [
    'AI_PROVIDER' => 'gemini',
    'GEMINI_API_KEY' => '',
    'GEMINI_MODEL' => 'gemini-2.5-flash',
    'GEMINI_USE_VERTEX' => 'N',
    'DEEPSEEK_API_KEY' => '',
    'DEEPSEEK_MODEL' => 'deepseek-chat',
    'OPENAI_API_KEY' => '',
    'OPENAI_MODEL' => 'gpt-4o-mini',
    'CHAT_LOG_ENABLED' => 'Y',
    'CHAT_LOG_DIR' => '',
    'CHAT_WELCOME' => 'Здравствуйте! Помогу подобрать товар, сравнить модели и ответить по ценам и наличию. Чем могу помочь?',
    'CATALOG_SOURCE' => 'yml_url',
    'CATALOG_URL' => '/bitrix/catalog_export/catalog.xml',
    'CATALOG_PATH' => '',
    'CATALOG_IBLOCK_ID' => '',
    'CATALOG_REFRESH_MINUTES' => '60',
    'CATALOG_PROFILE' => 'auto',
    'SHOP_NAME' => 'Магазин',
    'SHOP_BRAND' => '',
    'SITE_URL' => '',
    'SHOP_SPECIALIZATION' => '',
    'BITRIX24_LEAD_ENABLED' => 'Y',
    'BITRIX24_WEBHOOK_URL' => '',
    'BITRIX24_ASSIGNED_ID' => '1',
    'BITRIX24_SOURCE_ID' => 'aichat',
    'BITRIX24_SOURCE_LABEL' => 'aichat',
    'CRM_LEAD_TITLE_PREFIX' => 'AI-чат',
    'YANDEX_METRIKA_ENABLED' => 'Y',
    'YANDEX_METRIKA_COUNTER_ID' => '90547846',
    'YANDEX_METRIKA_GOAL' => 'aibot',
    'CURL_SSL_VERIFY' => 'Y',
    'WIDGET_ENABLED' => 'Y',
    'AVATAR_FILE_ID' => '',
    'WIDGET_ACCENT_COLOR' => '#2563eb',
    'WIDGET_FAB_RIGHT' => '24',
    'WIDGET_FAB_BOTTOM' => '24',
    'WIDGET_AGENT_NAME' => '',
    'WIDGET_STATUS_TEXT' => 'Онлайн • отвечает сразу',
    'WIDGET_SHOW_ONLINE' => 'Y',
    'WIDGET_AUTO_INJECT' => 'N',
    'VOICE_ENABLED' => 'Y',
    'VOICE_REPLY_ENABLED' => 'N',
    'VOICE_STT_PROVIDER' => 'auto',
    'VOICE_GEMINI_STT_MODEL' => '',
    'VOICE_TTS_PROVIDER' => 'browser',
    'VOICE_TTS_VOICE' => 'alloy',
    'YANDEX_TTS_API_KEY' => '',
    'YANDEX_TTS_FOLDER_ID' => '',
    'YANDEX_TTS_VOICE' => 'jane',
    'CRM_B24_FIELD_MAP' => '',
    'CRM_LOCAL_FIELD_MAP' => '',
    'CRM_LOCAL_ENABLED' => 'N',
    'CRM_EMAIL_ENABLED' => 'N',
    'CRM_EMAIL_TO' => '',
    'VOICE_MAX_SECONDS' => '60',
    'VOICE_TTS_MAX_CHARS' => '500',
    'RATE_LIMIT_PER_MINUTE' => '60',
    'PROMPT_ROLE_LINE' => 'Ты — AI-консультант «{shop_name}» ({brand}). Отвечай живым языком, как консультант в чате.',
    'PROMPT_SMALL_TALK_HINT' => 'На «кто ты» / «что умеешь» — только 1–3 предложения о себе, БЕЗ товаров, цен и ссылок.',
    'PROMPT_SEARCH_RULES' => "ПОДБОР ТОВАРОВ (делаешь ты, не скрипт):\n- В списке «Каталог» ниже — ВСЕ товары магазина. Сам находи подходящие по запросу.\n- Не придумывай позиции, цены и ссылки вне списка.\n- Игнорируй прошлые ошибочные ответы ассистента — только каталог ниже.",
    'PROMPT_CATALOG_SYNONYMS' => '',
    'PROMPT_STYLE_BRIEF' => 'Режим: ПОДБОР. 4–6 предложений + 1–3 товара. Каждый товар: **[Название](ссылка из каталога)** — цена · наличие · параметры.',
    'PROMPT_STYLE_DETAILED' => 'Режим: ПОДРОБНЫЙ ОТВЕТ. Структура: заголовок **модель**, характеристики из каталога, описание, для кого подойдёт, ссылка **[Название](url)** — цена · наличие.',
    'PROMPT_RULES_COMMON' => 'Правила: товары и цены — только из каталога ниже; доставка, оплата, дилеры, техника — из справочника FAQ. Ссылки markdown, русский язык.',
    'PROMPT_DOMAIN_RULES' => "Не здоровайся в каждом сообщении.",
    'PROMPT_CATALOG_HEADER' => 'Каталог (формат: [id] название | категория | цена | наличие | ссылка | характеристики):',
    'PROMPT_LINK_RULES' => 'У каждого товара в каталоге есть URL — оформляй товар как **[Название](URL)**. Не пиши, что ссылок нет.',
    'PROMPT_FAQ_INTRO' => 'Вопросы о доставке, оплате, дилерах, сервисе и технических деталях вне каталога — отвечай ТОЛЬКО по справочнику ниже. Не выдумывай сроки, цены и города. Если ответа нет в справочнике — предложи менеджера {brand} и оставить телефон в чате.',
    'PROMPT_FAQ_KNOWLEDGE' => <<<'FAQ'
# keywords: доставка, доставить, срок, стоимость, город, регион, йошкар, транспорт
# title: Доставка
ЗАПОЛНИТЕ: сроки и ориентир стоимости доставки по регионам (в т.ч. Йошкар-Ола). Точный расчёт — менеджер после заявки или по телефону на сайте.

# keywords: оплата, оплатить, при получении, наложенный, трицикл, рассрочка, карт
# title: Оплата
ЗАПОЛНИТЕ: способы оплаты, возможна ли оплата при получении для трициклов и другой техники.

# keywords: сцепление, сухое, масляная, ванна, бензокосилка, редуктор, муфта
# title: Сцепление и трансмиссия
ЗАПОЛНИТЕ: тип сцепления (сухое / в масляной ванне) по вашим моделям — укажите конкретные линейки.

# keywords: задний редуктор, редуктор, мини трактор, трактор, модель, от чего
# title: Редуктор мини-трактора
ЗАПОЛНИТЕ: от какого агрегата задний редуктор, каталожные модели/артикулы.

# keywords: дилер, диллер, официальный, город, салон, где купить, представитель
# title: Дилеры и города
ЗАПОЛНИТЕ: список городов с официальными дилерами или ссылку на страницу дилеров на сайте.

# keywords: ковш, объём, объем, стрела, подъём, подъем, высота, погрузчик, экскаватор
# title: Ковш и стрела
ЗАПОЛНИТЕ: объём ковша и высота подъёма стрелы по моделям (из паспорта/прайса).
FAQ,
    'INTENT_SMALL_TALK_REGEX' => '^(ты\s+кто|кто\s+ты|что\s+(?:ты\s+)?умеешь|чем\s+(?:ты\s+)?можешь|привет|здравствуйте|добрый\s+день|help|помощь)[!.?\s]*$',
    'INTENT_PRODUCT_KEYWORDS_REGEX' => 'подобр|купить|цена|наличи|характеристик|сравни|какой\s+лучше|модел|нужен|нужна|хочу',
    'INTENT_PURCHASE_INTENT_REGEX' => 'хочу\s+купить|готов\s+купить|оформ(ить|ляю)|беру\b|заказать|куплю\b',
    'INTENT_SHOPPING_INTENT_REGEX' => 'подобр|купить|цена|наличи|характеристик|сравни|какой\s+лучше|модел|нужен|нужна|хочу',
    'INTENT_TOPIC_WORDS' => '',
    'INTENT_MOTORCYCLE_QUERY_REGEX' => '',
    'INTENT_MOTORCYCLE_APPEND_KEYWORD' => 'мотоцикл',
    'MSG_LEAD_PHONE_CTA' => "\n\nЕсли удобно — оставьте номер телефона: менеджер {brand} перезвонит и поможет с выбором.",
    'MSG_LEAD_PHONE_CTA_PROMPT' => 'ОБЯЗАТЕЛЬНО заверши ответ последней строкой с просьбой оставить номер телефона для звонка менеджера {brand}.',
    'MSG_PHONE_REPLY_OK' => 'Спасибо! Записал номер {phone}. Менеджер {brand} перезвонит.',
    'MSG_PHONE_REPLY_FALLBACK' => 'Спасибо! Номер {phone} принят — менеджер {brand} свяжется с вами.',
];
